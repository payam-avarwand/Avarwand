##############-Avarwand Persian Wikipedia Editor-################

# Created:      Payam Avarwand - 17.07.2025
# Last change:  Payam Avarwand - 26.10.2025

###################################################- L i b.
import pywikibot
import re
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import json
import base64
import tempfile
from io import BytesIO
import getpass
import sys
from pathlib import Path
import webbrowser
from urllib.parse import quote

###################################################- V A R s
# Set working directory to the script's directory
script_dir = Path(__file__).parent.resolve()
os.chdir(script_dir)

# Destination Website
site = pywikibot.Site("fa", "wikipedia")

# Config.json
CONFIG_FILE = os.path.join(script_dir, "config.json")

# F o n t
FONT_FAMILY = "Tahoma"
FONT_SIZE = 9
FONT_BOLD = (FONT_FAMILY, 12, "bold")
FONT_REGULAR = (FONT_FAMILY, FONT_SIZE)

# C a t e g o r i e s
CATEGORY_LIST = [
    "رده:طبیعت استان خوزستان",
    "رده:استان خوزستان",
    "رده:شهرستان حمیدیه",
    "رده:شهرستان شوش",
    "رده:تحریف نام خلیج فارس",
    "رده:نویسندگان دانشنامه ایرانیکا",
    "رده:روستاهای شهرستان شوش",
    "رده:شوش",
    "رده:بناهای تاریخی شوش",
    "رده:اهالی شوش",
    "رده:شوش (شهر باستانی)",
    "رده:شهرستان آبادان",
    "رده:شهرستان اندیمشک",
    "رده:شهرستان اهواز",
    "رده:شهرستان بهبهان",
    "رده:مناطق مسکونی در شهرستان بهبهان",
    "رده:روستاهای شهرستان بهبهان",
    "رده:بناهای تاریخی شهرستان بهبهان",
    "رده:شهرستان‌های استان خوزستان",
    "رده:شهرستان بندر ماهشهر",
    "رده:شهرستان دزپارت",
    "رده:رامهرمز",
    "رده:دشت آزادگان",
    "رده:شهرستان رامهرمز",
    "رده:مرکز استان‌های ایران",
    "رده:شهرهای استان خوزستان",
    "رده:شهرهای رودگذر",
    "رده:معماری ساسانی",
    "رده:شهرهای باستانی متروک ایران",
    "رده:محوطه‌های باستان‌شناختی در ایران",
    "رده:شهرهای ساسانیان",
    "رده:اردشیر بابکان",
    "رده:ایران‌شناسی",
    "رده:ساختمان‌ها و سازه‌ها در اهواز",
    "رده:ساختمان‌ها و سازه‌ها در استان خوزستان",
    "رده:ترابری در استان خوزستان",
    "رده:بالاشهر",
    "رده:عشایر لر ایران",
    "رده:استان‌های ایران",
    "رده:گویش بختیاری",
    "رده:شبکه‌های استانی سیمای جمهوری اسلامی ایران",
    "رده:کاریکاتوریست‌های اهل ایران",
    "رده:زبان‌های ایران",
    "رده:محله‌های اهواز",
    "رده:مناطق مسکونی در استان خوزستان",
    "رده:پل‌های استان خوزستان"
]

###################################################- F U N C T I O N s

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"خطا در بارگذاری config.json: {e}")
            return {}
    return {}
#- - - - - - - - - - - - - - - - - - - - - - - - - -
def save_config(cfg):
    try:
        config_dir = os.path.dirname(CONFIG_FILE)
        if not os.access(config_dir, os.W_OK):
            raise PermissionError(f"عدم دسترسی به دایرکتوری: {config_dir}")
        if os.path.exists(CONFIG_FILE):
            if os.name == 'nt':
                os.system(f'attrib -h -r "{CONFIG_FILE}"')
            else:
                os.chmod(CONFIG_FILE, 0o666)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        if os.name == 'nt':
            os.system(f'attrib +h "{CONFIG_FILE}"')
    except PermissionError as e:
        temp_config = os.path.join(tempfile.gettempdir(), "pwe_config.json")
        try:
            with open(temp_config, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
            print(f"فایل تنظیمات به دلیل خطای دسترسی در {temp_config} ذخیره شد.")
            return temp_config
        except Exception as e2:
            messagebox.showerror("خطا", f"خطا در ذخیره فایل تنظیمات:\n{e2}\nبرنامه بدون فایل تنظیمات ادامه می‌دهد.")
            return None
    except Exception as e:
        messagebox.showerror("خطا", f"خطا در ذخیره فایل تنظیمات:\n{e}\nبرنامه بدون فایل تنظیمات ادامه می‌دهد.")
        return None
#- - - - - - - - - - - - - - - - - - - - - - - - - -

def is_logged_in(site_obj):
    try:
        if site_obj is None:
            return False, None
        user = site_obj.user()
        if user and user.is_loggedin():
            return True, user.username
        return False, None
    except Exception as e:
        print(f"خطا در بررسی وضعیت لاگین: {e}")
        return False, None
#- - - - - - - - - - - - - - - - - - - - - - - - - -

def request_login_if_needed(root):
    global site
    if site is None:
        site = pywikibot.Site("fa", "wikipedia")
    is_logged, username = is_logged_in(site)
    if is_logged:
        return True, username
    login_dialog = tk.Toplevel(root)
    login_dialog.title("نیاز به ورود")
    login_dialog.transient(root)
    login_dialog.grab_set()
    login_dialog.focus_set()
    login_dialog.geometry("400x200")
    login_dialog.resizable(False, False)
    screen_width = login_dialog.winfo_screenwidth()
    screen_height = login_dialog.winfo_screenheight()
    x = (screen_width - 400) // 2
    y = (screen_height - 200) // 2
    login_dialog.geometry(f"400x200+{x}+{y}")
    login_result = tk.StringVar()
    login_status = tk.StringVar(value="برای ادامه، لطفاً وارد شوید")
        
    def cancel():
        login_result.set("cancel")
        login_dialog.destroy()
    
    ttk.Label(login_dialog, text="نیاز به ورود به ویکی‌پدیا", font=FONT_BOLD, justify="center").pack(pady=15)
    ttk.Label(login_dialog, textvariable=login_status, font=FONT_REGULAR, justify="center").pack(pady=10)
    btn_frame = ttk.Frame(login_dialog)
    btn_frame.pack(pady=20)
    ttk.Button(btn_frame, text="لغو", command=cancel).pack(side="right", padx=5)
    login_dialog.protocol("WM_DELETE_WINDOW", cancel)
    root.wait_window(login_dialog)
    if login_result.get() == "cancel":
        return False, None
    is_logged, username = login_result.get()
    return is_logged, username
#- - - - - - - - - - - - - - - - - - - - - - - - - -

def ensure_file_path(filename, label, root, is_user_config=False):
    config = load_config()
    if filename in config and os.path.exists(config[filename]):
        return config[filename]
    
    while True:
        dialog = tk.Toplevel(root)
        dialog.title("فایل یافت نشد")
        dialog.transient(root)
        dialog.grab_set()
        dialog.focus_set()
        dialog.geometry("400x180")
        dialog.resizable(False, False)
        screen_width = dialog.winfo_screenwidth()
        screen_height = dialog.winfo_screenheight()
        x = (screen_width - 400) // 2
        y = (screen_height - 180) // 2
        dialog.geometry(f"400x180+{x}+{y}")
        dialog.protocol("WM_DELETE_WINDOW", lambda: None)
        
        if is_user_config:
            # فقط برای فایل تنظیمات Pywikibot - فقط امکان وارد کردن فایل موجود
            ttk.Label(dialog, text=f"!پیدا نشد user-config.py فایل\n\nلطفاً آن را وارد کنید", font=FONT_REGULAR, justify="center").pack(pady=15)
        else:
            # برای فایل‌های قواعد و رده‌ها - امکان ایجاد فایل جدید
            ttk.Label(dialog, text=f"!فایل '{label}' پیدا نشد\nچه کنم؟", font=FONT_REGULAR, justify="center").pack(pady=15)
        
        result = tk.StringVar()
        
        def import_file():
            result.set("import")
            dialog.destroy()
        
        def create_file():
            result.set("create")
            dialog.destroy()
            
        def cancel():
            result.set("cancel")
            dialog.destroy()
        
        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(pady=15)
        
        if is_user_config:
            # فقط برای فایل تنظیمات Pywikibot - فقط دکمه وارد کردن فایل موجود
            ttk.Button(btn_frame, text="!فایل از قبل ایجاد شده در مسیرجاری را وارد کن", command=import_file).pack(side="right", padx=5)
        else:
            # برای فایل‌های قواعد و رده‌ها - هر دو دکمه
            ttk.Button(btn_frame, text="!فایل از قبل ایجاد شده را وارد کن", command=import_file).pack(side="right", padx=5)
            ttk.Button(btn_frame, text="!فایل جدید بساز", command=create_file).pack(side="right", padx=5)
        
        ttk.Button(btn_frame, text="خروج", command=cancel).pack(side="right", padx=5)
        root.wait_window(dialog)
        
        if result.get() == "cancel":
            return "CANCEL"
        
        file_path = None
        if result.get() == "import":
            file_path = filedialog.askopenfilename(
                title=f"انتخاب فایل {label}",
                filetypes=[("Python Files", "*.py") if is_user_config else ("JSON Files", "*.json") if filename.endswith(".json") else ("Text Files", "*.txt")]
            )
        elif result.get() == "create" and not is_user_config:
            # فقط برای فایل‌های قواعد و رده‌ها امکان ایجاد فایل جدید
            file_path = filedialog.asksaveasfilename(
                title=f"ایجاد فایل جدید برای {label}",
                initialfile=filename,
                defaultextension=".py" if is_user_config else os.path.splitext(filename)[1],
                filetypes=[("Python Files", "*.py") if is_user_config else ("JSON Files", "*.json") if filename.endswith(".json") else ("Text Files", "*.txt")]
            )
            if file_path:
                try:
                    if filename.endswith(".json"):
                        default_rules = RuleManagerApp.DEFAULT_RULES
                        data = [{"pattern": p, "replacement": r, "help": h} for (p, r, h) in default_rules]
                        with open(file_path, "w", encoding="utf-8") as f:
                            json.dump(data, f, ensure_ascii=False, indent=2)
                    else:
                        default_cats = [
                            "رده:طبیعت استان خوزستان",
                            "رده:استان خوزستان",
                            "رده:شهرستان حمیدیه",
                            "رده:شهرستان شوش",
                            "رده:تحریف نام خلیج فارس",
                            "رده:نویسندگان دانشنامه ایرانیکا",
                            "رده:روستاهای شهرستان شوش",
                            "رده:شوش",
                            "رده:بناهای تاریخی شوش",
                            "رده:اهالی شوش",
                            "رده:شوش (شهر باستانی)",
                            "رده:شهرستان آبادان",
                            "رده:شهرستان اندیمشک",
                            "رده:شهرستان اهواز",
                            "رده:شهرستان بهبهان",
                            "رده:مناطق مسکونی در شهرستان بهبهان",
                            "رده:روستاهای شهرستان بهبهان",
                            "رده:بناهای تاریخی شهرستان بهبهان",
                            "رده:شهرستان‌های استان خوزستان",
                            "رده:شهرستان بندر ماهشهر",
                            "رده:شهرستان دزپارت",
                            "رده:رامهرمز",
                            "رده:دشت آزادگان",
                            "رده:شهرستان رامهرمز",
                            "رده:مرکز استان‌های ایران",
                            "رده:شهرهای استان خوزستان",
                            "رده:شهرهای رودگذر",
                            "رده:معماری ساسانی",
                            "رده:شهرهای باستانی متروک ایران",
                            "رده:محوطه‌های باستان‌شناختی در ایران",
                            "رده:شهرهای ساسانیان",
                            "رده:اردشیر بابکان",
                            "رده:ایران‌شناسی",
                            "رده:ساختمان‌ها و سازه‌ها در اهواز",
                            "رده:ساختمان‌ها و سازه‌ها در استان خوزستان",
                            "رده:ترابری در استان خوزستان",
                            "رده:بالاشهر",
                            "رده:عشایر لر ایران",
                            "رده:استان‌های ایران",
                            "رده:گویش بختیاری",
                            "رده:شبکه‌های استانی سیمای جمهوری اسلامی ایران",
                            "رده:کاریکاتوریست‌های اهل ایران",
                            "رده:زبان‌های ایران",
                            "رده:محله‌های اهواز",
                            "رده:مناطق مسکونی در استان خوزستان",
                            "رده:پل‌های استان خوزستان"
                        ]
                        with open(file_path, "w", encoding="utf-8") as f:
                            f.write("\n".join(default_cats))
                except PermissionError as e:
                    messagebox.showerror("خطا", f"عدم دسترسی برای ایجاد فایل {filename}:\n{e}")
                    continue
        
        if file_path:
            config[filename] = file_path
            new_config_path = save_config(config)
            if new_config_path:
                global CONFIG_FILE
                CONFIG_FILE = new_config_path
            return file_path
        
        if is_user_config:
            messagebox.showwarning("هشدار", f"لطفاً فایل '{label}' را انتخاب کنید.")
        else:
            messagebox.showwarning("هشدار", f"لطفاً فایل '{label}' را انتخاب یا ایجاد کنید.")
#- - - - - - - - - - - - - - - - - - - - - - - - - -

def setup_pywikibot_config(root):
    config = load_config()
    user_config_file = config.get("user-config.py", None)
    if not user_config_file or not os.path.exists(user_config_file):
        user_config_file = ensure_file_path("user-config.py", "تنظیمات Pywikibot", root, is_user_config=True)
        if user_config_file == "CANCEL":
            return None
    if user_config_file:
        pywikibot_dir = os.path.dirname(user_config_file)
        if not os.access(pywikibot_dir, os.W_OK):
            messagebox.showerror("خطا", f"عدم دسترسی نوشتن به دایرکتوری Pywikibot: {pywikibot_dir}")
            return None
        os.environ['PYWIKIBOT_DIR'] = pywikibot_dir
        return user_config_file
    return None
#- - - - - - - - - - - - - - - - - - - - - - - - - -

def correct_persian_y(widget):
    try:
        if isinstance(widget, tk.Entry):
            text = widget.get()
            corrected = text.replace("\u064A", "\u06CC")
            if text != corrected:
                cursor_pos = widget.index(tk.INSERT)
                widget.delete(0, tk.END)
                widget.insert(0, corrected)
                widget.icursor(cursor_pos)
        elif isinstance(widget, tk.Text):
            text = widget.get("1.0", tk.END).strip()
            corrected = text.replace("\u064A", "\u06CC")
            if text != corrected:
                cursor_pos = widget.index(tk.INSERT)
                widget.delete("1.0", tk.END)
                widget.insert("1.0", corrected)
                widget.mark_set(tk.INSERT, cursor_pos)
    except Exception as e:
        print(f"خطا در اصلاح حرف ی: {e}")
#- - - - - - - - - - - - - - - - - - - - - - - - - -

def ezafe_y_fix(text):
    pattern = r"(\s)([اآء-ی]{2,})\s(ای)(\s)([اآء-ی]{2,})"
    def replacer(match):
        before_word = match.group(2)
        if not before_word.endswith("ه"):
            return match.group(0)
        return f"{match.group(1)}{before_word}\u200C{match.group(3)}{match.group(4)}{match.group(5)}"
    return re.sub(pattern, replacer, text)


def apply_rules_protected(text, rules, protect_links_and_templates=False, remove_extra_spaces=True):
    """
    اعمال قواعد با محافظت از لینک‌ها، قالب‌ها، تصاویر و کدهای CSS/HTML
    """
    if not text:
        return text
    
    # مرحله 1: حذف فواصل پشت سرهم (اگر فعال باشد)
    if remove_extra_spaces:
        text = re.sub(r'[^\S\r\n]{2,}', ' ', text)
    
    # محافظت از تصاویر در هر شرایطی (همیشه فعال)
    protected_patterns = [
        # تصاویر و فایل‌ها - همه انواع (همیشه محافظت شوند)
        r'(\[\[(File|Image|پرونده|تصویر):.*?\]\])',
        r'(\[\[(File|Image|پرونده|تصویر):.*?\.(jpg|jpeg|png|gif|svg|webp).*?\]\])',
        r'(\b\w+\.(jpg|jpeg|png|gif|svg|webp)\b)',  # نام فایل‌های تصویر
    ]
    
    # اگر کاربر گزینه "اعمال بر روی لینک‌ها و قالب‌ها" را فعال کرده باشد
    if protect_links_and_templates:
        # اعمال قواعد روی کل متن (بدون محافظت از لینک‌ها و قالب‌ها)
        # اما تصاویر همچنان محافظت می‌شوند
        segments = []
        remaining_text = text
        
        # فقط تصاویر را محافظت می‌کنیم
        for pattern in protected_patterns:
            pos = 0
            matches = list(re.finditer(pattern, remaining_text, re.DOTALL | re.IGNORECASE))
            for match in matches:
                start, end = match.span()
                # متن قبل از بخش محافظت شده (غیرمحافظت شده)
                if start > pos:
                    segments.append(('normal', remaining_text[pos:start]))
                # بخش محافظت شده (تصاویر)
                segments.append(('protected', match.group(0)))
                pos = end
            
            # به روز رسانی متن باقیمانده
            if pos < len(remaining_text):
                remaining_text = remaining_text[pos:]
            else:
                remaining_text = ""
            pos = 0
        
        # اگر متن باقیمانده داریم، اضافه کنیم
        if remaining_text:
            segments.append(('normal', remaining_text))
        
        # فقط روی بخش‌های غیرمحافظت شده قواعد را اعمال کنیم
        processed_segments = []
        for seg_type, content in segments:
            if seg_type == 'normal':
                # اعمال قواعد روی متن عادی (شامل لینک‌ها و قالب‌ها)
                for pattern, replacement, _help in rules:
                    try:
                        content = re.sub(pattern, replacement, content)
                    except re.error:
                        continue
            processed_segments.append(content)
        
        # ترکیب مجدد همه بخش‌ها
        text = ''.join(processed_segments)
    else:
        # محافظت فعال - فقط روی متن عادی اعمال شود
        # الگوهای محافظت شده (شامل تصاویر + لینک‌ها + قالب‌ها)
        full_protected_patterns = protected_patterns + [
            # تصاویر و فایل‌ها - همه انواع
            r'(\[\[(File|Image|پرونده|تصویر):.*?\]\])',
            r'(\[\[(File|Image|پرونده|تصویر):.*?\.(jpg|jpeg|png|gif|svg|webp).*?\]\])',
            
            # لینک‌های ویکی
            r'(\[\[.*?\]\])',
            r'(<ref[^>]*>.*?</ref>)',
            r'(&lt;ref[^&gt;]*&gt;.*?&lt;/ref&gt;)',
            
            # قالب‌ها
            # {{}}
            r'({{.*?}})',
            r'(\{\{.*?\}\})',
            # <>
            r'(\<.*?\>)',
            # :px and :< and :>
            r'([a-zA-Z-]+:\s*\d+px)'
            r'(\:.*?\<)',
            r'(\:.*?\>)',
            
            # تگ‌های HTML و CSS
            r'(<[^>]*>)',
            r'(<style.*?>.*?</style>)',
            r'(<div[^>]*>.*?</div>)',
            r'(<span[^>]*>.*?</span>)',
            r'(<table[^>]*>.*?</table>)',
            r'(<tr[^>]*>.*?</tr>)',
            r'(<td[^>]*>.*?</td>)',
            r'(<th[^>]*>.*?</th>)',
            
            # تگ‌های تکی با استایل
            r'(<[^>]+style="[^"]*"[^>]*>)',
            r'(<[^>]+class="[^"]*"[^>]*>)',
            
            # منابع و کدها
            r'(<ref.*?>.*?</ref>)',
            r'(<nowiki>.*?</nowiki>)',
            r'(<code>.*?</code>)',
            r'(<pre>.*?</pre>)',
            r'(<math>.*?</math>)',
            
            # URLها و لینک‌های خارجی
            r'(https?://[^\s<>"]+)',
            r'(www\.[^\s<>"]+)',
            
            # نام فایل‌های تصویر در متن
            r'(\b\w+\.(jpg|jpeg|png|gif|svg|webp)\b)',
            
            # جداول ویکی
            r'({\|.*?\|\})',
            
            # گالری
            r'(<gallery.*?>.*?</gallery>)',
        ]
        
        # متن را به بخش‌های محافظت شده و غیرمحافظت شده تقسیم کنیم
        segments = []
        remaining_text = text
        
        for pattern in full_protected_patterns:
            pos = 0
            matches = list(re.finditer(pattern, remaining_text, re.DOTALL | re.IGNORECASE))
            for match in matches:
                start, end = match.span()
                # متن قبل از بخش محافظت شده (غیرمحافظت شده)
                if start > pos:
                    segments.append(('normal', remaining_text[pos:start]))
                # بخش محافظت شده
                segments.append(('protected', match.group(0)))
                pos = end
            
            # به روز رسانی متن باقیمانده
            if pos < len(remaining_text):
                remaining_text = remaining_text[pos:]
            else:
                remaining_text = ""
            pos = 0
        
        # اگر متن باقیمانده داریم، اضافه کنیم
        if remaining_text:
            segments.append(('normal', remaining_text))
        
        # فقط روی بخش‌های غیرمحافظت شده قواعد را اعمال کنیم
        processed_segments = []
        for seg_type, content in segments:
            if seg_type == 'normal':
                # اعمال قواعد روی متن عادی
                for pattern, replacement, _help in rules:
                    try:
                        content = re.sub(pattern, replacement, content)
                    except re.error:
                        continue
            processed_segments.append(content)
        
        # ترکیب مجدد همه بخش‌ها
        text = ''.join(processed_segments)
    
    # اعمال سایر اصلاحات عمومی
    text = ezafe_y_fix(text)
    text = re.sub(r'\u064B', '', text)
    
    return text

###################################################- G U I : Rule manager

class RuleManagerApp:
    HELP_TEXT_DEFAULT = """
۱- الگوها، از ساختار دستوری "رگیولار اکسپرشن" استفاده می کنند
۲- شیوه‌ی اعمال قاعده‌ها به‌ترتیب است، یعنی قاعده‌ای که در خط بالاتر است، زودتر اعمال می‌شود
۳- دقت کنید که علامت سوالی که در قواعد استفاده می شود، به صورت ? است، و نه ؟
۴- برای حذف یک کلمه در متن، در زمان نوشتن قاعده، نوار جایگزین را خالی رها می‌کنیم

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

📖 Guide:
................................................................................................

Rule Structure: جایگزین → الگو 
------------------------------------

مثال‌های ساده:
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

• Pattern: \\bمارکتینگ\\b
  Replacement: بازاریابی
  Result: "مارکتینگ" becomes "بازاریابی"
____________________________________

• Pattern: \\bپکیج\\b  
  Replacement: بسته
  Result: "پکیج" becomes "بسته"
____________________________________

• Pattern: \\bفولدر\\b
  Replacement: پوشه
  Result: "فولدر" becomes "پوشه"

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Special Regex Characters:

• \\b : Word boundary (whole words only): تضمین می‌کند که کلمه دقیقا به صورت جداگانه پیدا شود
• ^ : Start of text
• $ : End of text  
• . : Any character
• * : available 0 or more times
• + : available 1 or more times
• ? : available 0 or 1 time
• [] : Character set (means "or") like : [ی,ئ]
• () : Grouping
------------------------------------

Advanced Examples:
------------------------------------
• Pattern: \\s+می\\s+شود\\b
  Replacement: می‌شود
  Result: Fixes space in "می شود"
____________________________________

• Pattern: (\\S)\\s+(های|هایی|ها)\\b
  Replacement: \\1‌\\2
  Result: "کتاب های" becomes "کتاب‌های"
____________________________________

Important Tips:
- - - - - - - - 
1. Use \\b to match complete words only
2. For Persian half-space use \\u200C
3. Groups are accessible with \\1, \\2, etc.
4. Patterns are case-sensitive
5. Use | for multiple options (OR logic)
6. Test your patterns before saving

Payam Avarwand
پیام اوروند

"""

    DEFAULT_RULES = [
        (r'\bطوایف\b(?=\s*(?:$|[،,؛;:!\?\.]|\r?\n|==|\b(?:از|به|با|در|بر|و|برای|تا|روی|زیر|مثل)\b))', 'طایفه‌ها', "Replace plural طوایف with طایفه‌ها before punctuation or specific words."),
        (r'\bطوایف\b', 'طایفه‌های', "General replacement of طوایف with طایفه‌های."),
        (r'\bایلات\b(?=\s*(?:$|[،,؛;:!\?\.]|\r?\n|==|\b(?:از|به|با|در|بر|و|برای|تا|روی|زیر|مثل)\b))', 'ایل‌ها', "Replace plural ایلات with ایل‌ها before punctuation or specific words."),
        (r'\bایلات\b', 'ایل‌های', "General replacement of ایلات with ایل‌های."),
        (r'\bتکلم می‌نمایند\b', 'صحبت می‌کنند', "Replace formal phrase with simpler phrase."),
        (r'\bساکنان\b', 'شهروندان', "Replace ساکنان with شهروندان."),
        (r"\bمی باشد\b", " می‌باشد", "Add half-space in idiomatic verb می‌باشد."),
        (r"\bنمی تواند\b", " نمی‌تواند", "Add half-space in idiomatic verb نمی‌تواند."),
        (r"\bمی کند\b", " می‌کند", "Add half-space in idiomatic verb می‌کند."),
        (r"\bمی شود\b", " می‌شود", "Add half-space in idiomatic verb می‌شود."),
        (r"\bدر حالی(?:\s?است|\s?ست)\b", "در حالی‌ست", "Simplify expression."),
        (r'\bشده اند\b', 'شده‌اند', "Add half-space in شده‌اند for Persian text standardization."),
        (r'\bتکلم می‌کنند\b', 'صحبت می‌کنند', "Replace تکلم می‌کنند with صحبت می‌کنند for Persian text standardization."),
        (r'\bتکلم می کنند\b', 'صحبت می‌کنند', "Replace تکلم می کنند with صحبت می‌کنند for Persian text standardization."),
        (r'\bمردمانی\b', 'مردمی', "Replace مردمانی with مردمی for Persian text standardization."),
        (r'\bآپدیت\b', 'به‌روزرسانی', "Replace آپدیت with به‌روزرسانی for Persian text standardization."),
        (r'\bآپلود\b', 'بارگذاری', "Replace آپلود with بارگذاری for Persian text standardization."),
        (r'\bجلوگیری\b', 'پیشگیری', "Replace جلوگیری with پیشگیری for Persian text standardization."),
        (r'\bتامین\b|\bتأمین\b', 'فراهم', "Replace تامین or تأمین with فراهم for Persian text standardization."),
        (r'\bنمایان\b', 'آشکار', "Replace نمایان with آشکار for Persian text standardization."),
        (r'\bمابین\b', 'میان', "Replace مابین with میان for Persian text standardization."),
        (r'\bساکنین\b', 'شهروندان', "Replace ساکنین with شهروندان for Persian text standardization."),
        (r'\bقرن\b', 'سده', "Replace قرن with سده for Persian text standardization."),
        (r'\bاکثرا(?:|ً)?\b', 'بیشتر', "Replace اکثرا with بیشتر for Persian text standardization."),
        (r'\bاکثر\b', 'بیشتر', "Replace اکثر with بیشتر for Persian text standardization."),
        (r'(?<!مالک\s)\bفعلی\b', 'کنونی', "Replace فعلی with کنونی (except after مالک) for Persian text standardization."),
        (r'\bبه ویژه\b', 'به‌ویژه', "Add half-space in به‌ویژه for Persian text standardization."),
        (r'\bاستراتژیک\b', 'راهبردی', "Replace استراتژیک with راهبردی for Persian text standardization."),
        (r'\bبه[\s]?واسطه\b', 'به‌جهت', "Replace به واسطه with به‌جهت for Persian text standardization."),
        (r'\bپروژه\b', 'برنامه', "Replace پروژه with برنامه for Persian text standardization."),
        (r'\bمتصل می‌کند\b', 'پیوند می‌دهد', "Replace متصل می‌کند with پیوند می‌دهد for Persian text standardization."),
        (r'\bپاسپورت\b', 'گذرنامه', "Replace پاسپورت with گذرنامه for Persian text standardization."),
        (r'\bدایما\b', 'همیشه', "Replace دایما with همیشه for Persian text standardization."),
        (r'\bدائما\b', 'همیشه', "Replace دائما with همیشه for Persian text standardization."),
        (r'\bصدمه\b', 'آسیب', "Replace صدمه با آسیب for Persian text standardization."),
        (r'\bاصابت\b', 'برخورد', "Replace اصابت با برخورد for Persian text standardization."),
        (r'\bآرشیو\b', 'بایگانی', "Replace آرشیو با بایگانی for Persian text standardization."),
        (r'\bپرسنل\b', 'کارکنان', "Replace پرسنل با کارکنان for Persian text standardization."),
        (r'\bمحسوب\b', 'شمرده', "Replace محسوب با شمرده for Persian text standardization."),
        (r'\bحمایت\b', 'پشتیبانی', "Replace حمایت با پشتیبانی for Persian text standardization."),
        (r'\bمجروح\b', 'زخمی', "Replace مجروح با زخمی for Persian text standardization."),
        (r'\bشکایت\b', 'دادخواست', "Replace شکایت با دادخواست for Persian text standardization."),
        (r'\bمحاکمه\b', 'دادرسی', "Replace محاکمه با دادرسی for Persian text standardization."),
        (r'\bقابل قبول\b', 'پذیرفتنی', "Replace قابل قبول با پذیرفتنی for Persian text standardization."),
        (r'\bضرر\b', 'زیان', "Replace ضرر با زیان for Persian text standardization."),
        (r'\bجراحت\b', 'زخم', "Replace جراحت با زخم for Persian text standardization."),
        (r'\bلعنت\b', 'نفرین', "Replace لعنت با نفرین for Persian text standardization."),
        (r'\bنزاع\b', 'درگیری', "Replace نزاع با درگیری for Persian text standardization."),
        (r'\bخصوصیت\b', 'ویژگی', "Replace خصوصیت با ویژگی for Persian text standardization."),
        (r'\bمخصوص\b', 'ویژه', "Replace مخصوص با ویژه for Persian text standardization."),
        (r'\bتاجر\b', 'بازرگان', "Replace تاجر با بازرگان for Persian text standardization."),
        (r'\bموزیک\b', 'آهنگ', "Replace موزیک با آهنگ for Persian text standardization."),
        (r'\bحالا\b', 'اکنون', "Replace حالا با اکنون for Persian text standardization."),
        (r'\bیأس\b', 'ناامیدی', "Replace یأس با ناامیدی for Persian text standardization."),
        (r'\bمأیوس\b', 'ناامید', "Replace مأیوس با ناامید for Persian text standardization."),
        (r'\bموفق\b(?!\s+(?:از|به|با|بر|برای|تا|روی|زیر|مثل))', 'پیروز', "Replace موفق with پیروز unless followed by specific prepositions."),
        (r'\bکثیف\b', 'آلوده', "Replace کثیف با آلوده for Persian text standardization."),
        (r'\bمجرا\b|\bمجرای\b', 'بستر', "Replace مجرا or مجرای with بستر for Persian text standardization."),
        (r'\bابلیس\b', 'اهریمن', "Replace ابلیس با اهریمن for Persian text standardization."),
        (r'(?<!روشن )(?<=\s)قیاس\b', 'سنجش', "Replace قیاس با سنجش (except after روشن) for Persian text standardization."),
        (r'\bمذکوره\b|\bمذکور\b', 'ذکرشده', "Replace مذکوره or مذکور with ذکرشده for Persian text standardization."),
        (r'\bکلینیک\b', 'درمانگاه', "Replace کلینیک با درمانگاه for Persian text standardization."),
        (r'\bاکوسیستم\b', 'زیست‌بوم', "Replace اکوسیستم با زیست‌بوم for Persian text standardization."),
        (r'\bعضله\b', 'ماهیچه', "Replace عضله با ماهیچه for Persian text standardization."),
        (r'\bآفیسر\b', 'افسر', "Replace آفیسر با افسر for Persian text standardization."),
        (r'\bمانیتور\b', 'صفحه‌نمایش', "Replace مانیتور با صفحه‌نمایش for Persian text standardization."),
        (r'\bپرینتر\b', 'چاپگر', "Replace پرینتر با چاپگر for Persian text standardization."),
        (r'\bکامپیوتر\b', 'رایانه', "Replace کامپیوتر با رایانه for Persian text standardization."),
        (r'\bپروگرام\b', 'برنامه', "Replace پروگرام با برنامه for Persian text standardization."),
        (r'\bریکاوری\b', 'بازیابی', "Replace ریکاوری با بازیابی for Persian text standardization."),
        (r'\bکنفرانس\b', 'همایش', "Replace کنفرانس با همایش for Persian text standardization."),
        (r'\bگالری\b', 'نگارخانه', "Replace گالری با نگارخانه for Persian text standardization."),
        (r'\bپرفسور\b', 'استاد', "Replace پرفسور با استاد for Persian text standardization."),
        (r'\bمارکتینگ\b', 'بازاریابی', "Replace مارکتینگ با بازاریابی for Persian text standardization."),
        (r'\bپکیج\b', 'بسته', "Replace پکیج با بسته for Persian text standardization."),
        (r'\bفولدر\b', 'پوشه', "Replace فولدر با پوشه for Persian text standardization."),
        (r'\bبالاخص\b', 'به‌ویژه', "Replace بالاخص با به‌ویژه for Persian text standardization."),
        (r'\bبطور\b', 'به‌طور', "Replace بطور با به‌طور for Persian text standardization."),
        (r'\bعلیرغم\b', 'با‌وجود', "Replace علیرغم با با‌وجود for Persian text standardization."),
        (r'\bعلی‌رغم\b', 'با‌وجود', "Replace علی‌رغم با با‌وجود for Persian text standardization."),
        (r'\bفی‌الواقع\b', 'درحقیقت', "Replace فی‌الواقع با درحقیقت for Persian text standardization."),
        (r'\bبمنظور\b', 'به‌منظور', "Replace بمنظور با به‌منظور for Persian text standardization."),
        (r'\bفی‌المجموع\b', 'در مجموع', "Replace فی‌المجموع با در مجموع for Persian text standardization."),
        (r'\bمجددا(?:‌|ً)?\b', 'از نو', "Replace مجددا با از نو for Persian text standardization."),
        (r'\bمتعاقبا(?:‌|ً)?\b', 'سرانجام', "Replace متعاقبا با سرانجام for Persian text standardization."),
        (r'\bموقتا(?:|ً)?\b', 'به‌طور موقت', "Replace موقتا با به‌طور موقت for Persian text standardization."),
        (r'\bعمدا(?:‌|ً)?\b', 'به‌عمد', "Replace عمدا با به‌عمد for Persian text standardization."),
        (r'\bابدا(?:‌|ً)?\b', 'به‌هیچ‌ وجه', "Replace ابدا با به‌هیچ‌وجه for Persian text standardization."),
        (r'\bعمدتا(?:‌|ً)?\b', 'به‌طور عمده', "Replace عمدتا با به‌طور عمده for Persian text standardization."),
        (r'\bتقریبا(?:‌|ً)?\b', 'به‌طور تقریبی', "Replace تقریبا با به‌طور تقریبی for Persian text standardization."),
        (r'\bاصالتا(?:|ً)?\b', 'در اصل', "Replace اصالتا با در اصل for Persian text standardization."),
        (r'\bاصلا(?:|ً)?\b', 'در اصل', "Replace اصلا با در اصل for Persian text standardization."),
        (r'\bمستقیما(?:‌|ً)?\b', 'به‌طورمستقیم', "Replace مستقیما با به‌طورمستقیم for Persian text standardization."),
        (r'\bاحتمالا(?:‌|ً)?\b', 'به‌احتمال زیاد', "Replace احتمالا با به‌احتمال زیاد for Persian text standardization."),
        (r'\bعموما(?:‌|ً)?\b', 'به‌طور عمومی', "Replace عموما با به‌طور عمومی for Persian text standardization."),
        (r'\bبعضا(?:‌|ً)?\b', 'گاهی', "Replace بعضا با گاهی for Persian text standardization."),
        (r'\bقاعدتا(?:|ً)?\b', 'در اصل', "Replace قاعدتا با در اصل for Persian text standardization."),
        (r'\bصرفا(?:‌|ً)?\b', 'تنها', "Replace صرفا با تنها for Persian text standardization."),
        (r'\bحتما(?:|ً)?\b', 'به‌حتم', "Replace حتما با به‌حتم for Persian text standardization."),
        (r'\bنهایتا(?:|ً)?\b', 'در نهایت', "Replace نهایتا با در نهایت for Persian text standardization."),
        (r'\bحقیقتا(?:‌|ً)?\b', 'درحقیقت', "Replace حقیقتا با درحقیقت for Persian text standardization."),
        (r'\bکاملا(?:‌|ً)?\b', 'به‌طورکامل', "Replace کاملا با به‌طورکامل for Persian text standardization."),
        (r'\bمجموعا(?:‌|ً)?\b', 'به‌طورکل', "Replace مجموعا با به‌طورکل for Persian text standardization."),
        (r'\bرسما(?:‌|ً)?\b', 'به‌طور رسمی', "Replace رسما با به‌طور رسمی for Persian text standardization."),
        (r'\bنسبتا(?:‌|ً)?\b', 'به‌نسبت', "Replace نسبتا با به‌نسبت for Persian text standardization."),
        (r'\bخصوصا(?:‌|ً)?\b', 'به‌خصوص', "Replace خصوصا با به‌خصوص for Persian text standardization."),
        (r'\bمعمولا(?:‌|ً)?\b', 'به‌طورمعمول', "Replace معمولا با به‌طورمعمول for Persian text standardization."),
        (r'\bمتقابلا(?:‌|ً)?\b', 'به‌طورمشابه', "Replace متقابلا با به‌طورمشابه for Persian text standardization."),
        (r'\bواضحا(?:‌|ً)?\b', 'به‌طورواضح', "Replace واضحا با به‌طورواضح for Persian text standardization."),
        (r'\bاخیرا(?:‌|ً)?\b', 'به‌تازگی', "Replace اخیرا با به‌تازگی for Persian text standardization."),
        (r'\bتماما(?:‌|ً)?\b', 'به‌طورکل', "Replace تماما با به‌طورکل for Persian text standardization."),
        (r'\bمخصوصا(?:‌|ً)?\b', 'به‌خصوص', "Replace مخصوصا با به‌خصوص for Persian text standardization."),
        (r'\bمستمرا(?:‌|ً)?\b', 'به‌طور مستمر', "Replace مستمرا با به‌طور مستمر for Persian text standardization."),
        (r'\bقطع[اًا](?:‌|ً)?\b', 'به‌قطع', "Replace قطعاً/قطعا با به‌قطع for Persian text standardization."),
        (r'\bحدود[اًا](?:‌|ً)?\b', 'به‌طور حدودی', "Replace حدوداً/حدودا با به‌طور حدودی for Persian text standardization."),
        (r'\bغالب[اًا](?:‌|ً)?\b', 'اغلب', "Replace غالباً/غالبا با اغلب for Persian text standardization."),
        (r'\bظاهرا(?:‌|ً)?\b', 'در ظاهر،', "Replace ظاهرا با در ظاهر، for Persian text standardization."),
        (r'\bعملا(?:‌|ً)?\b', 'به‌طورعملی', "Replace عملا با به‌طورعملی for Persian text standardization."),
        (r'\bمسلما(?:‌|ً)?\b', 'به‌طورمسلم', "Replace مسلما با به‌طورمسلم for Persian text standardization."),
        (r'\bمحتملا(?:|ً)?\b', 'به احتمال‌زیاد', "Replace محتملا با به احتمال‌زیاد for Persian text standardization."),
        (r'\bجمعا(?:|ً)?\b', 'سرجمع', "Replace جمعا با سرجمع for Persian text standardization."),
        (r'\bیقینا(?:‌|ً)?\b', 'بی شک', "Replace یقینا با بی شک for Persian text standardization."),
        (r'\bمثلا(?:‌|ً)?\b', 'به‌طورمثال', "Replace مثلا با به‌طورمثال for Persian text standardization."),
        (r'\bشرعا(?:‌|ً)?\b', 'به‌طورشرعی', "Replace شرعا با به‌طورشرعی for Persian text standardization."),
        (r'\bکلا(?:‌|ً)?\b', 'به‌طورکلی', "Replace کلا با به‌طورکلی for Persian text standardization."),
        (r'\bمنحصرا(?:‌|ً)?\b', 'به‌طور انحصاری', "Replace منحصرا با به‌طور انحصاری for Persian text standardization."),
        (r'\bقبلا(?:‌|ً)?\b', 'در گذشته', "Replace قبلا با در گذشته for Persian text standardization."),
        (r'\bبعدا(?:‌|ً)?\b', 'بعدها', "Replace بعدا با بعدها for Persian text standardization."),
        (r'\bطبیعتا(?:‌|ً)?\b', 'به طبع', "Replace طبیعتا با به طبع for Persian text standardization."),
        (r'\bمشخصا(?:‌|ً)?\b', 'به‌طور مشخص', "Replace مشخصا با به‌طور مشخص for Persian text standardization."),
        (r'\bاصولا(?:|ً)?\b', 'به‌طوراساسی', "Replace اصولا با به‌طوراساسی for Persian text standardization."),
        (r'\bسابقا(?:‌|ً)?\b', 'تا پیش از این،', "Replace سابقا با تا پیش از این، for Persian text standardization."),
        (r'\bمطلقا(?:‌|ً)?\b', 'به هیچ وجه', "Replace مطلقا با به هیچ وجه for Persian text standardization."),
        (r'\bاشتباها\b', 'به اشتباه', "Replace اشتباهاً با به اشتباه for Persian text standardization."),
        (r'\bاساسا\b', 'در اساس', "Replace اساسا با در اساس for Persian text standardization."),
        (r'\bعینا\b', 'به‌طورعینی', "Replace عینا با به‌طورعینی for Persian text standardization."),
        (r' {2,}', ' ', "Replace multiple spaces with a single space for Persian text standardization."),
        (r' ,', ',', "Remove space before comma for Persian text standardization."),
        (r"\sمی ?شود\b", " می‌شود", "Add half-space in می‌شود for Persian text standardization."),
        (r'\bرسم الخط\b', 'رسم‌الخط', "Add half-space in رسم‌الخط for Persian text standardization."),
        (r'\bهفته نامه\b', 'هفته‌نامه', "Add half-space in هفته‌نامه for Persian text standardization."),
        (r"\sمی ?باشد", " می‌باشد", "Add half-space in می‌باشد for Persian text standardization."),
        (r"\sمی ?توان\b", " می‌توان", "Add half-space in می‌توان for Persian text standardization."),
        (r"\sمی ?تواند\b", " می‌تواند", "Add half-space in می‌تواند for Persian text standardization."),
        (r"\sمی ?شوند\b", " می‌شوند", "Add half-space in می‌شوند for Persian text standardization."),
        (r"\sمی ?نماید\b", " می‌نماید", "Add half-space in می‌نماید for Persian text standardization."),
        (r'\bراه آهن\b', 'راه‌آهن', "Add half-space in راه‌آهن for Persian text standardization."),
        (r"\bبی بهره\b", "بی‌بهره", "Add half-space in بی‌بهره for Persian text standardization."),
        (r'\bتا کنون\b', 'تاکنون', "Replace تا کنون with تاکنون for Persian text standardization."),
        (r'\bمیکنم\b', 'می‌کنم', "Add half-space in می‌کنم for Persian text standardization."),
        (r"\sنمی ?شود\b", " نمی‌شود", "Add half-space in نمی‌شود for Persian text standardization."),
        (r"\bهیچگونه\b", "هیچ‌گونه", "Add half-space in هیچ‌گونه for Persian text standardization."),
        (r"\sنمی ?کند\b", " نمی‌کند", "Add half-space in نمی‌کند for Persian text standardization."),
        (r"\sنمی ?باشد\b", " نمی‌باشد", "Add half-space in نمی‌باشد for Persian text standardization."),
        (r"\sمی ?خواست\b", " می‌خواست", "Add half-space in می‌خواست for Persian text standardization."),
        (r"\sنمی ?آورد\b", " نمی‌آورد", "Add half-space in نمی‌آورد for Persian text standardization."),
        (r"\sنمی ?خواهد\b", " نمی‌خواهد", "Add half-space in نمی‌خواهد for Persian text standardization."),
        (r"\sنمی ?گیرد\b", " نمی‌گیرد", "Add half-space in نمی‌گیرد for Persian text standardization."),
        (r"\sنمی ?دهد\b", " نمی‌دهد", "Add half-space in نمی‌دهد for Persian text standardization."),
        (r'\bتازه ‌وارد\b', 'تازه‌وارد', "Add half-space in تازه‌وارد for Persian text standardization."),
        (r'(\S) (تر\b)', r'\1‌\2', "Add half-space before تر for Persian text standardization."),
        (r"\sنمی ?بیند\b", " نمی‌بیند", "Add half-space in نمی‌بیند for Persian text standardization."),
        (r"\sنمی ?آید\b", " نمی‌آید", "Add half-space in نمی‌آید for Persian text standardization."),
        (r"\sمی ?آورد\b", " می‌آورد", "Add half-space in می‌آورد for Persian text standardization."),
        (r"\sمی ?دهد\b", " می‌دهد", "Add half-space in می‌دهد for Persian text standardization."),
        (r'(\S)\s+(های|هایی|ها)\b', r'\1‌\2', "Add half-space before های/هایی/ها for Persian text standardization."),
        (r"\sمی ?فرماید\b", " می‌فرماید", "Add half-space in می‌فرماید for Persian text standardization."),
        (r"\sمی ?فرمایند\b", " می‌فرمایند", "Add half-space in می‌فرمایند for Persian text standardization."),
        (r"\sمی ?گیرند\b", " می‌گیرند", "Add half-space in می‌گیرند for Persian text standardization."),
        (r"\sمی ?گیرد\b", " می‌گیرد", "Add half-space in می‌گیرد for Persian text standardization."),
        (r"\sمی ?خواهند\b", " می‌خواهند", "Add half-space in می‌خواهند for Persian text standardization."),
        (r'\bبصورت\b', 'به صورت', "Replace بصورت with به صورت for Persian text standardization."),
        (r"\sمی ?خواهد\b", " می‌خواهد", "Add half-space in می‌خواهد for Persian text standardization."),
        (r'\bمیگردد\b', 'می‌گردد', "Add half-space in می‌گردد for Persian text standardization."),
        (r'\bدانش نامه\b', 'دانش‌نامه', "Add half-space in دانش‌نامه for Persian text standardization."),
        (r'\bهیچکدام\b', 'هیچ‌کدام', "Add half-space in هیچ‌کدام for Persian text standardization."),
        (r"\sمی ?توانند\b", " می‌توانند", "Add half-space in می‌توانند for Persian text standardization."),
        (r"\sمی ?دانند\b", " می‌دانند", "Add half-space in می‌دانند for Persian text standardization."),
        (r"\sمی ?داند\b", " می‌داند", "Add half-space in می‌داند for Persian text standardization."),
        (r"\sمی ?بینند\b", " می‌بینند", "Add half-space in می‌بینند for Persian text standardization."),
        (r"\sمی ?بیند\b", " می‌بیند", "Add half-space in می‌بیند for Persian text standardization."),
        (r"(?<!\S)به طور(?!\S)", "به‌طور", "Add half-space in به‌طور for Persian text standardization."),
        (r"(?<!\S)در حال(?!\S)", "درحال", "Replace در حال with درحال for Persian text standardization."),
        (r"(?<!\S)از جمله(?!\S)", "ازجمله", "Replace از جمله with ازجمله for Persian text standardization."),
        (r"(?<!\S)به دلیل(?!\S)", "به‌دلیل", "Add half-space in به‌دلیل for Persian text standardization."),
        (r"\bپیش فرض\b", " پیش‌فرض", "Add half-space in پیش‌فرض for Persian text standardization."),
        (r"\bپس زمینه\b", " پس‌زمینه", "Add half-space in پس‌زمینه for Persian text standardization.")
    ]

    def __init__(self, root, parent=None, initialize=True):
        self.root = root
        self.parent = parent
        
        # متغیر برای checkbox حذف فواصل پشت سرهم باید قبل از load_rules تعریف شود
        self.remove_extra_spaces_var = tk.BooleanVar(value=True)  # پیش‌فرض فعال
        self.protect_links_var = tk.BooleanVar(value=False)  # پیش‌فرض غیرفعال - این خط تغییر کرد
        
        if initialize:
            self.root.title("مدیریت قواعد")
            self.root.transient(parent.root)
            self.root.grab_set()  # این خط باعث می‌شود پنجره modal باشد
            self.root.focus_force()
            self.root.protocol("WM_DELETE_WINDOW", self.close_window)
            self.parent.center_window(self.root, 1100, 600)
        
        self.rules = self.load_rules()
        
        if initialize:
            self.create_widgets()

    def center_window(self, win, width, height):
        screen_width = win.winfo_screenwidth()
        screen_height = win.winfo_screenheight()
        x = int((screen_width - width) / 2)
        y = int((screen_height - height) / 2)
        win.geometry(f"{width}x{height}+{x}+{y}")

    def close_window(self):
        self.root.grab_release()  # آزاد کردن focus هنگام بستن
        self.root.destroy()

    def load_rules(self):
        config = load_config()
        file_path = config.get("rls.json", None)
        if not file_path or not os.path.exists(file_path):
            return list(self.DEFAULT_RULES)
        
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            # بارگذاری قواعد
            if isinstance(data, list):
                rules = [(d.get("pattern", ""), d.get("replacement", ""), d.get("help", "")) for d in data]
            else:  # فرمت جدید با تنظیمات
                rules = [(d.get("pattern", ""), d.get("replacement", ""), d.get("help", "")) for d in data.get("rules", [])]
                self.remove_extra_spaces_var.set(data.get("remove_extra_spaces", True))
                self.protect_links_var.set(data.get("protect_links_and_templates", False))
        except Exception as e:
            if self.root and self.root.winfo_exists():
                messagebox.showerror("خطا", f"خطا در بارگذاری قواعد:\n{e}")
            rules = list(self.DEFAULT_RULES)
        return rules

    def save_rules(self):
        config = load_config()
        file_path = config.get("rls.json", None)
        if not file_path:
            messagebox.showerror("خطا", "مسیر فایل قواعد یافت نشد.")
            return
        
        data = {
            "rules": [{"pattern": p, "replacement": r, "help": h} for (p, r, h) in self.rules],
            "remove_extra_spaces": self.remove_extra_spaces_var.get(),
            "protect_links_and_templates": self.protect_links_var.get()
        }
        try:
            if os.path.exists(file_path) and os.name == 'nt':
                os.system(f'attrib -h -r "{file_path}"')
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            if os.name == 'nt':
                os.system(f'attrib +h "{file_path}"')
            if self.root.winfo_exists():
                messagebox.showinfo("اطلاع", "قواعد با موفقیت ذخیره شدند.")
                self.root.lift()
                self.root.focus_force()
        except Exception as e:
            if self.root.winfo_exists():
                messagebox.showerror("خطا", f"خطا در ذخیره قواعد:\n{e}")

    def select_new_rule_file(self):
        file_path = filedialog.askopenfilename(
            title="انتخاب فایل قواعد جدید",
            filetypes=[("JSON Files", "*.json")]
        )
        if not file_path:
            return
        config = load_config()
        config["rls.json"] = file_path
        save_config(config)
        self.rules = self.load_rules()
        self.refresh_rule_list()
        messagebox.showinfo("اطلاع", f"فایل قواعد به {file_path} تغییر یافت.")
        self.root.lift()
        self.root.focus_force()
    
    def create_widgets(self):
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill="both", expand=True, padx=5, pady=5)
        
        # بخش جستجو
        search_rule_frame = ttk.Frame(main_frame)
        search_rule_frame.pack(fill="x", padx=5, pady=5)
        ttk.Label(search_rule_frame, text="جستجو:", font=FONT_REGULAR, anchor="e").pack(side="right")
        self.rule_search_var = tk.StringVar()
        self.rule_search_var.trace_add("write", self.filter_rules)
        self.rule_search_entry = tk.Entry(search_rule_frame, textvariable=self.rule_search_var, font=FONT_REGULAR, justify="right")
        self.rule_search_entry.pack(side="right", fill="x", expand=True, padx=5)
        self.rule_search_entry.bind("<KeyRelease>", lambda e: correct_persian_y(self.rule_search_entry))
        self.parent.create_context_menu(self.rule_search_entry)
        ttk.Button(search_rule_frame, text="پاک کردن", command=lambda: self.rule_search_var.set("")).pack(side="right", padx=5)
        
        # بخش اصلی (لیست قواعد و دکمه‌ها)
        content_frame = ttk.Frame(main_frame)
        content_frame.pack(fill="both", expand=True)
        
        # فریم برای لیست قواعد با اسکرول بار
        rule_list_frame = ttk.Frame(content_frame)
        rule_list_frame.pack(side="right", fill="both", expand=True)
        
        # اسکرول بار عمودی برای لیست قواعد
        rule_scrollbar = ttk.Scrollbar(rule_list_frame)
        rule_scrollbar.pack(side="right", fill="y")
        
        self.rule_list = tk.Listbox(
            rule_list_frame, 
            font=FONT_REGULAR, 
            yscrollcommand=rule_scrollbar.set
        )
        self.rule_list.pack(side="left", fill="both", expand=True)
        self.rule_list.bind("<Double-1>", self.show_rule_help)
        rule_scrollbar.config(command=self.rule_list.yview)
        
        self.refresh_rule_list()
############################################################################        
        # دکمه‌های سمت چپ
        right_frame = ttk.Frame(content_frame)
        right_frame.pack(side="left", fill="y", padx=5)
        ttk.Button(right_frame, text="افزودن یک قاعده", command=self.add_rule).pack(fill="x", pady=2)
        ttk.Button(right_frame, text="حذف قاعده", command=self.delete_rule).pack(fill="x", pady=2)
        ttk.Button(right_frame, text="ویرایش قاعده", command=self.edit_rule).pack(fill="x", pady=2)
        ttk.Button(right_frame, text="ایجاد کپی", command=self.clone_rule).pack(fill="x", pady=2)
        ttk.Button(right_frame, text="جابجایی به بالا", command=self.move_rule_up).pack(fill="x", pady=2)
        ttk.Button(right_frame, text="جابجایی به پایین", command=self.move_rule_down).pack(fill="x", pady=2)
        ttk.Button(right_frame, text="انتخاب یک بانک قاعده دیگر", command=self.select_new_rule_file).pack(fill="x", pady=2)

        # تعریف فونت B Titr برای دکمه‌ها
        BUTTON_FONT = ("B Titr", 13)  # فونت B Titr با سایز 11

        # دکمه ذخیره با رنگ سبز
        save_button = tk.Button(
            right_frame, 
            text="ذخیره", 
            command=self.save_rules,
            bg="#55DD59",           # رنگ پس‌زمینه سبز
            fg="black",             # رنگ متن سیاه
            font=BUTTON_FONT,       # فونت B Titr
            relief="raised",        # حالت برجسته
            bd=2,                   # ضخامت حاشیه
            padx=5,
            pady=2,
            cursor="hand2"          # تغییر cursor به دست
        )
        save_button.pack(fill="x", pady=5)

        # دکمه خروج با رنگ قرمز
        exit_button = tk.Button(
            right_frame, 
            text="خــــــروج", 
            command=self.close_window,
            bg="#f3564b",           # رنگ پس‌زمینه قرمز
            fg="black",             # رنگ متن سیاه
            font=BUTTON_FONT,       # فونت B Titr
            relief="raised",        # حالت برجسته
            bd=2,                   # ضخامت حاشیه
            padx=5,
            pady=2,
            cursor="hand2"          # تغییر cursor به دست
        )
        exit_button.pack(fill="x", pady=2)

        # متغیر برای پیگیری وضعیت کلیک
        save_pressed = False
        exit_pressed = False

        # اضافه کردن افکت hover و کلیک برای دکمه ذخیره (سبز)
        def on_enter_save(e):
            if not save_pressed:
                save_button['bg'] = '#45a049'  # سبز تیره‌تر هنگام hover

        def on_leave_save(e):
            if not save_pressed:
                save_button['bg'] = '#4CAF50'  # بازگشت به سبز اصلی

        def on_press_save(e):
            global save_pressed
            save_pressed = True
            save_button['bg'] = '#1b5e20'  # سبز خیلی تیره هنگام کلیک

        def on_release_save(e):
            global save_pressed
            save_pressed = False
            save_button['bg'] = '#4CAF50'  # بازگشت به سبز اصلی

        save_button.bind("<Enter>", on_enter_save)
        save_button.bind("<Leave>", on_leave_save)
        save_button.bind("<ButtonPress-1>", on_press_save)
        save_button.bind("<ButtonRelease-1>", on_release_save)

        # اضافه کردن افکت hover و کلیک برای دکمه خروج (قرمز)
        def on_enter_exit(e):
            if not exit_pressed:
                exit_button['bg'] = '#d32f2f'  # قرمز تیره‌تر هنگام hover

        def on_leave_exit(e):
            if not exit_pressed:
                exit_button['bg'] = '#f44336'  # بازگشت به قرمز اصلی

        def on_press_exit(e):
            global exit_pressed
            exit_pressed = True
            exit_button['bg'] = '#7f0000'  # قرمز خیلی تیره هنگام کلیک

        def on_release_exit(e):
            global exit_pressed
            exit_pressed = False
            exit_button['bg'] = '#f44336'  # بازگشت به قرمز اصلی

        exit_button.bind("<Enter>", on_enter_exit)
        exit_button.bind("<Leave>", on_leave_exit)
        exit_button.bind("<ButtonPress-1>", on_press_exit)
        exit_button.bind("<ButtonRelease-1>", on_release_exit)
        
############################################################################
        
        # بخش راهنما
        help_frame = ttk.LabelFrame(self.root, text="راهنما")
        help_frame.pack(fill="both", expand=True, padx=5, pady=5)
        
        # ایجاد فریم برای متن راهنما و اسکرول بار
        help_text_frame = ttk.Frame(help_frame)
        help_text_frame.pack(fill="both", expand=True)
        
        # اسکرول بار عمودی برای متن راهنما
        help_scrollbar = ttk.Scrollbar(help_text_frame)
        help_scrollbar.pack(side="right", fill="y")
        
        # اسکرول بار افقی برای متن راهنما
        help_scrollbar_h = ttk.Scrollbar(help_text_frame, orient="horizontal")
        help_scrollbar_h.pack(side="bottom", fill="x")
        
        self.help_text_widget = tk.Text(
            help_text_frame, 
            height=8, 
            wrap="word", 
            font=FONT_REGULAR,
            yscrollcommand=help_scrollbar.set,
            xscrollcommand=help_scrollbar_h.set
        )
        self.help_text_widget.pack(side="left", fill="both", expand=True)
        
        help_scrollbar.config(command=self.help_text_widget.yview)
        help_scrollbar_h.config(command=self.help_text_widget.xview)
        
        # تنظیم جهت متن به LTR
        self.help_text_widget.tag_configure("ltr", justify="left")
        
        self.help_text_widget.insert("1.0", self.HELP_TEXT_DEFAULT, "ltr")
        self.help_text_widget.bind("<KeyRelease>", lambda e: correct_persian_y(self.help_text_widget))
        self.help_text_widget.configure(state="disabled")
        self.parent.create_context_menu(self.help_text_widget)
    
        # بخش تنظیمات در مدیریت قواعد
        settings_frame = ttk.LabelFrame(main_frame, text="تنظیمات")
        settings_frame.pack(fill="x", padx=5, pady=5)
        
        # checkbox برای حذف فواصل پشت سرهم
        remove_spaces_cb = ttk.Checkbutton(
            settings_frame, 
            text="حذف فواصل پشت سرهم",
            variable=self.remove_extra_spaces_var
        )
        remove_spaces_cb.pack(padx=10, pady=5, anchor="w")
        
        # checkbox برای محافظت از لینک‌ها و قالب‌ها
        protect_links_cb = ttk.Checkbutton(
            settings_frame, 
            text="اعمال قواعد بر روی آدرسهای پیوند و کدهای وب",
            variable=self.protect_links_var
        )
        protect_links_cb.pack(padx=10, pady=5, anchor="w")
    
    def filter_rules(self, *args):
        self.refresh_rule_list()

    def refresh_rule_list(self):
        self.rule_list.delete(0, "end")
        search_term = self.rule_search_var.get().strip().lower()
        for idx, (pattern, repl, _help) in enumerate(self.rules, 1):
            if not search_term or search_term in pattern.lower() or search_term in repl.lower():
                display_text = f"{idx}. {pattern} → {repl}"
                self.rule_list.insert("end", display_text)

    def show_rule_help(self, event):
        sel = self.rule_list.curselection()
        if not sel:
            return
        idx = sel[0]
        displayed_rule = self.rule_list.get(idx)
        rule_idx = int(displayed_rule.split(".")[0]) - 1
        _, _, help_text = self.rules[rule_idx]
        self.help_text_widget.configure(state="normal")
        self.help_text_widget.delete("1.0", "end")
        self.help_text_widget.tag_configure("rtl", justify="right")
        self.help_text_widget.insert("1.0", help_text if help_text else "هیچ راهنمایی برای این قاعده در دسترس نیست.", "rtl")
        self.help_text_widget.configure(state="disabled")

    def add_rule(self):
        def save_new_rule():
            patt = pattern_entry.get().strip()
            repl = repl_entry.get().strip()
            help_txt = help_entry.get("1.0", "end").strip()
            use_word_boundary = use_boundary_var.get()
            auto_convert_y = auto_convert_y_var.get()
            
            if not patt:
                messagebox.showerror("خطا", "الگو نباید خالی باشد.")
                return
            
            # اگر کاربر انتخاب کرده، \b اضافه کن
            if use_word_boundary and not patt.startswith(r'\b') and not patt.startswith('^') and not patt.endswith('$'):
                patt = f"\\b{patt}\\b"
            
            self.rules.append((patt, repl, help_txt))
            self.refresh_rule_list()
            self.save_rules()
            add_win.destroy()
            self.root.lift()
            self.root.focus_force()
            self.root.grab_set()
            
        def update_save_button(*args):
            current_pattern = pattern_var.get().strip()
            current_repl = repl_var.get().strip()
            current_help = help_entry.get("1.0", "end").strip()
            if current_pattern or current_repl or current_help:
                save_button.config(state="normal")
            else:
                save_button.config(state="disabled")
        
        def toggle_y_conversion():
            """تغییر وضعیت تبدیل خودکار ی"""
            if auto_convert_y_var.get():
                # فعال کردن تبدیل خودکار
                pattern_entry.bind("<KeyRelease>", lambda e: correct_persian_y(pattern_entry))
                repl_entry.bind("<KeyRelease>", lambda e: correct_persian_y(repl_entry))
                help_entry.bind("<KeyRelease>", lambda e: correct_persian_y(help_entry))
            else:
                # غیرفعال کردن تبدیل خودکار
                pattern_entry.unbind("<KeyRelease>")
                repl_entry.unbind("<KeyRelease>")
                help_entry.unbind("<KeyRelease>")

        add_win = tk.Toplevel(self.root)
        add_win.title("افزودن قاعده جدید")
        add_win.transient(self.root)
        add_win.grab_set()
        add_win.focus_force()
        self.parent.center_window(add_win, 640, 420)  # ارتفاع بیشتر برای checkbox دوم
        
        pattern_var = tk.StringVar()
        repl_var = tk.StringVar()
        use_boundary_var = tk.BooleanVar(value=True)
        auto_convert_y_var = tk.BooleanVar(value=True)  # پیش‌فرض فعال
        
        ttk.Label(add_win, text="الگو (Regex):", font=FONT_REGULAR, anchor="e").pack(padx=10, pady=(10, 2), anchor="w")
        pattern_entry = tk.Entry(add_win, width=80, font=FONT_REGULAR, justify="right", textvariable=pattern_var)
        pattern_entry.pack(padx=10, pady=2, fill="x")
        self.parent.create_context_menu(pattern_entry)
        
        # checkbox اول برای \b
        use_boundary_cb = ttk.Checkbutton(add_win, text="استفاده از \\b برای تطبیق کامل کلمات", 
                                        variable=use_boundary_var)
        use_boundary_cb.pack(padx=10, pady=(5, 2), anchor="w")
        
        # checkbox دوم برای تبدیل خودکار ی
        auto_convert_y_cb = ttk.Checkbutton(add_win, text="تبدیل خودکار «ي» عربی به «ی» فارسی", 
                                        variable=auto_convert_y_var, command=toggle_y_conversion)
        auto_convert_y_cb.pack(padx=10, pady=(2, 2), anchor="w")
        
        ttk.Label(add_win, text="جایگزین:", font=FONT_REGULAR, anchor="e").pack(padx=10, pady=(8, 2), anchor="w")
        repl_entry = tk.Entry(add_win, width=80, font=FONT_REGULAR, justify="right", textvariable=repl_var)
        repl_entry.pack(padx=10, pady=2, fill="x")
        self.parent.create_context_menu(repl_entry)
        
        ttk.Label(add_win, text="راهنما:", font=FONT_REGULAR, anchor="e").pack(padx=10, pady=(8, 2), anchor="w")
        help_entry = tk.Text(add_win, height=6, width=80, font=FONT_REGULAR)
        help_entry.pack(padx=10, pady=2, fill="both", expand=True)
        self.parent.create_context_menu(help_entry)
        
        btn_frame = ttk.Frame(add_win)
        btn_frame.pack(pady=8)
        save_button = ttk.Button(btn_frame, text="ذخیره", command=save_new_rule, state="disabled")
        save_button.pack(side="right", padx=5)
        ttk.Button(btn_frame, text="خروج", command=add_win.destroy).pack(side="right", padx=5)
        
        pattern_var.trace_add("write", update_save_button)
        repl_var.trace_add("write", update_save_button)
        help_entry.bind("<KeyRelease>", update_save_button)
        
        # فعال کردن پیش‌فرض تبدیل خودکار
        toggle_y_conversion()

    def delete_rule(self):
        sel = self.rule_list.curselection()
        if not sel:
            messagebox.showwarning("هشدار", "قاعده‌ای انتخاب نشده است.")
            return
        idx = sel[0]
        displayed_rule = self.rule_list.get(idx)
        rule_idx = int(displayed_rule.split(".")[0]) - 1
        if messagebox.askyesno("تأیید حذف", "آیا از حذف این قاعده مطمئن هستید؟"):
            del self.rules[rule_idx]
            self.refresh_rule_list()
            self.save_rules()
            self.root.lift()
            self.root.focus_force()

    def edit_rule(self):
        sel = self.rule_list.curselection()
        if not sel:
            messagebox.showwarning("هشدار", "قاعده‌ای انتخاب نشده است.")
            return
        idx = sel[0]
        displayed_rule = self.rule_list.get(idx)
        rule_idx = int(displayed_rule.split(".")[0]) - 1
        old_pattern, old_repl, old_help = self.rules[rule_idx]

        def save_edited_rule():
            p = pattern_entry.get().strip()
            r = repl_entry.get().strip()
            h = help_entry.get("1.0", "end").strip()
            if not p:
                messagebox.showerror("خطا", "الگو نباید خالی باشد.")
                return
            self.rules[rule_idx] = (p, r, h)
            self.refresh_rule_list()
            self.save_rules()
            edit_win.destroy()
            self.root.lift()
            self.root.focus_force()
            self.root.grab_set()  # بازگرداندن حالت modal

        def update_save_button(*args):
            current_pattern = pattern_var.get().strip()
            current_repl = repl_var.get().strip()
            current_help = help_entry.get("1.0", "end").strip()
            if (current_pattern != old_pattern or
                current_repl != old_repl or
                current_help != old_help):
                save_button.config(state="normal")
            else:
                save_button.config(state="disabled")

        edit_win = tk.Toplevel(self.root)
        edit_win.title("ویرایش قاعده")
        edit_win.transient(self.root)
        edit_win.grab_set()
        edit_win.focus_force()
        self.parent.center_window(edit_win, 640, 300)
        pattern_var = tk.StringVar(value=old_pattern)
        repl_var = tk.StringVar(value=old_repl)
        ttk.Label(edit_win, text="الگو (Regex):", font=FONT_REGULAR, anchor="e").pack(padx=10, pady=(10, 2), anchor="w")
        pattern_entry = tk.Entry(edit_win, width=80, font=FONT_REGULAR, justify="right", textvariable=pattern_var)
        pattern_entry.pack(padx=10, pady=2, fill="x")
        pattern_entry.bind("<KeyRelease>", lambda e: correct_persian_y(pattern_entry))
        self.parent.create_context_menu(pattern_entry)
        ttk.Label(edit_win, text="جایگزین:", font=FONT_REGULAR, anchor="e").pack(padx=10, pady=(8, 2), anchor="w")
        repl_entry = tk.Entry(edit_win, width=80, font=FONT_REGULAR, justify="right", textvariable=repl_var)
        repl_entry.pack(padx=10, pady=2, fill="x")
        repl_entry.bind("<KeyRelease>", lambda e: correct_persian_y(repl_entry))
        self.parent.create_context_menu(repl_entry)
        ttk.Label(edit_win, text="راهنما:", font=FONT_REGULAR, anchor="e").pack(padx=10, pady=(8, 2), anchor="w")
        help_entry = tk.Text(edit_win, height=6, width=80, font=FONT_REGULAR)
        help_entry.insert("1.0", old_help)
        help_entry.pack(padx=10, pady=2, fill="both", expand=True)
        help_entry.bind("<KeyRelease>", lambda e: correct_persian_y(help_entry))
        self.parent.create_context_menu(help_entry)
        btn_frame = ttk.Frame(edit_win)
        btn_frame.pack(pady=8)
        save_button = ttk.Button(btn_frame, text="ذخیره", command=save_edited_rule, state="disabled")
        save_button.pack(side="right", padx=5)
        ttk.Button(btn_frame, text="خروج", command=edit_win.destroy).pack(side="right", padx=5)
        pattern_var.trace_add("write", update_save_button)
        repl_var.trace_add("write", update_save_button)
        help_entry.bind("<KeyRelease>", update_save_button)
        edit_win.grab_set()

    def clone_rule(self):
        sel = self.rule_list.curselection()
        if not sel:
            messagebox.showwarning("هشدار", "قاعده‌ای انتخاب نشده است.")
            return
        idx = sel[0]
        displayed_rule = self.rule_list.get(idx)
        rule_idx = int(displayed_rule.split(".")[0]) - 1
        pattern, repl, help_text = self.rules[rule_idx]
        self.rules.append((pattern, repl, help_text))
        self.refresh_rule_list()
        self.save_rules()
        messagebox.showinfo("اطلاع", "قاعده کپی شده و به انتهای لیست اضافه گردید.")
        self.root.lift()
        self.root.focus_force()

    def move_rule_up(self):
        """جابجایی قاعده انتخاب‌شده به ردیف بالاتر (بدون ذخیره خودکار)"""
        sel = self.rule_list.curselection()
        if not sel:
            messagebox.showwarning("هشدار", "قاعده‌ای انتخاب نشده است.")
            return
        idx = sel[0]
        if idx == 0:
            return  # اولین است
        self.rules[idx - 1], self.rules[idx] = self.rules[idx], self.rules[idx - 1]
        self.refresh_rule_list()
        self.rule_list.selection_set(idx - 1)
        self.rule_list.see(idx - 1)

    def move_rule_down(self):
        """جابجایی قاعده انتخاب‌شده به ردیف پایین‌تر (بدون ذخیره خودکار)"""
        sel = self.rule_list.curselection()
        if not sel:
            messagebox.showwarning("هشدار", "قاعده‌ای انتخاب نشده است.")
            return
        idx = sel[0]
        if idx == len(self.rules) - 1:
            return  # آخرین است
        self.rules[idx + 1], self.rules[idx] = self.rules[idx], self.rules[idx + 1]
        self.refresh_rule_list()
        self.rule_list.selection_set(idx + 1)
        self.rule_list.see(idx + 1)

###################################################- G U I : main

class WikiEditorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Avarwand PWE")
        user_config_file = setup_pywikibot_config(self.root)
        if not user_config_file:
            messagebox.showerror("خطا", "فایل تنظیمات Pywikibot یافت نشد یا لغو شد. برنامه متوقف شد.")
            self.root.destroy()
            return
        try:
            icon_data = "AAABAAEAgIAAAAEAIAAoCAEAFgAAACgAAACAAAAAAAEAAAEAIAAAAAAAAAgBAAAAAAAAAAAAAAAAAAAAAAA5ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/4WFhv//////////////////////9/f3/09PUf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/vby9//7+/v/9/f3//Pz8//v7+/+joqT/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/87Oj3/39/f////////////////////////////ra2u/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/09OUf/5+fn///////////////////////Hx8f9DQkX/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/3p6fP/////////////////////////////////5+fn/U1JV/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/n56f/////////////////////////////////4uKjP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/1dXV//////////////////////////////////////+0tLX/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/z8+Qf/s7Oz/////////////////////////////////39/f/zs6Pf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/2xrbf/+/v7///////////////////////////////////////r6+v9YV1r/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/gICC///////////////////////////////////////+/v7/cnFz/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/xcXG/////////////////////////////////////////////////7q6u/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//U1NX////////////////////////////////////////////Gxsf/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/1taXP/8/Pz//////////////////////////////////////////////////Pz8/1xcXv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Y2Jk//7+/v////////////////////////////////////////////z8/f9ZWFv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/tLO0////////////////////////////////////////////////////////////wMDB/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+3t7j//////////////////////////////////////////////////////62trv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0pKTP/39/f////////////////////////////////////////////////////////////9/f3/YWFj/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/TEtO//j4+P//////////////////////////////////////////////////////9PT0/0dGSP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/mpqb///////////////////////////////////////////////////////////////////////Gxcb/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+YmJn/////////////////////////////////////////////////////////////////lJOV/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0A/Qf/s7Oz///////////////////////////////////////////////////////////////////////7+/v9oZ2n/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/PTw//+jo6f/////////////////////////////////////////////////////////////////l5eb/PTw//zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/goGD/////////////////////////////////////////////////////////////////////////////////8vLzP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/98e33///////////////////////////////////////////////////////////////////////////95eHr/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//W1tf//////////////////////////////////////////////////////////////////////////////////v7+/21sb/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/87Oz////////////////////////////////////////////////////////////////////////////9DQ0P85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Z2Zo//7+/v//////////////////////////////////////////////////////////////////////////////////////0dHS/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9fXmH//f39/////////////////////////////////////////////////////////////////////////////f39/2BgYv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+7u7v////////////////////////////////////////////////////////////////////////////////////////////+/v7/c3N1/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/7Gxsv//////////////////////////////////////////////////////////////////////////////////////tbW2/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Tk1Q//r6+v////////////////////////////////////////////////////////////7+/v/////////////////////////////////W1tf/Ojk8/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9HRkn/9vb2///////////////////////////////////////////////////////////////////////////////////////4+Pj/TEtO/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+cm53////////////////////////////////////////////////////////////9/f3/kpGT//39/f////////////////////////////////94d3n/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/5WUlv////////////////////////////////////////////////////////////////////////////////////////////////+bm5z/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/PTw//+jo6f///////////////////////////////////////////////////////////9LS0/85ODv/wMDB/////////////////////////////////9zc3P88Oz3/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/88Oz7/5OTk/////////////////////////////////////////////////////////////////////////////////////////////////+vr6/8/PkH/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/97enz/////////////////////////////////////////////////////////////////fHt9/zk4O/9bWlz/+/v7/////////////////////////////////35+gP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/3V0dv/////////////////////////////////////////////////////////////////Dw8T//////////////////////////////////////4KCg/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/83Nzv///////////////////////////////////////////////////////////+bm5v89PD//OTg7/zk4O/+zs7T/////////////////////////////////4eHh/z08P/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/ysrL////////////////////////////////////////////////////////////8fHx/0ZFR//e3t7/////////////////////////////////1tbX/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9bW13//Pz9////////////////////////////////////////////////////////////kpGT/zk4O/85ODv/OTg7/1BPUv/39/f/////////////////////////////////hISF/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/1lZW//9/f3///////////////////////////////////////////////////////////+gn6D/OTg7/4uLjP/////////////////////////////////+/v7/aWhq/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/62srf////////////////////////////////////////////////////////////T09P9GRUj/OTg7/zk4O/85ODv/OTg7/6Wlpv/////////////////////////////////l5OX/Pz5B/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/rKut////////////////////////////////////////////////////////////9vb2/0xLTf85ODv/QkFE//Dw8P////////////////////////////////++vb//OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9EQ0b/8/Pz////////////////////////////////////////////////////////////q6qs/zk4O/85ODv/OTg7/zk4O/85ODv/SEdK//Hx8f////////////////////////////////+Kioz/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0VER//08/T///////////////////////////////////////////////////////////+vr6//OTg7/zk4O/85ODv/pKSl//////////////////////////////////r6+v9SUVT/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/4uKjP////////////////////////////////////////////////////////////z8/P9YV1n/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/mJiZ/////////////////////////////////+np6f9AP0L/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/jY2P////////////////////////////////////////////////////////////+/v7/1VVV/85ODv/OTg7/zk4O/9TUlX/+/v7/////////////////////////////////6Skpf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/86OTz/29vb////////////////////////////////////////////////////////////xsbH/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9BQEP/6urq/////////////////////////////////5GRk/85ODv/OTg7/zk4O/85ODv/OTg7/zo5PP/g4OH///////////////////////////////////////////////////////////++vr7/OTg7/zk4O/85ODv/OTg7/zk4O/+/vr//////////////////////////////////8PDw/0JBRP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/2dmaf/+/v7///////////////////////////////////////////////////////7+/v9wb3H/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+KiYv/////////////////////////////////7Ozs/0NCRf85ODv/OTg7/zk4O/85ODv/cXBy//7+/v///////////////////////////////////////////////////////f39/2VlZ/85ODv/OTg7/zk4O/85ODv/OTg7/2lpa///////////////////////////////////////i4qM/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/uLe5////////////////////////////////////////////////////////////3t7e/zo5PP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/z08P//h4OH/////////////////////////////////l5eY/zk4O/85ODv/OTg7/zk4O//Dw8T////////////////////////////////////////////////////////////R0NH/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Ojk8/9jY2f/////////////////////////////////e3t7/Ozo9/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0pJTP/4+Pj///////////////////////////////////////////////////////////+Lioz/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/3x7ff/////////////////////////////////w8PD/RURH/zk4O/85ODv/VVRX//z8/P///////////////////////////////////////////////////////////3l4ev85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/g4KE//////////////////////////////////////9wb3H/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/lJSW////////////////////////////////////////////////////////////8PDw/0JBRP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Ojk8/9bV1v////////////////////////////////+dnJ7/OTg7/zk4O/+mpqf////////////////////////////////////////////////////////////i4uL/Ozo9/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9AP0L/7e3t/////////////////////////////////8fHyP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zw7Pf/j4uP///////////////////////////////////////////////////////////+mpqf/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/bm5w//7+/v////////////////////////////Pz8/9JSEv/QkFE//Dw8P///////////////////////////////////////////////////////////4yLjf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+dnZ7//////////////////////////////////Pz8/1pZW/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/cnFz/////////////////////////////////////////////////////////////Pz8/1VUVv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/ysrL/////////////////////////////////6OjpP+JiIr////////////////////////////////////////////////////////////w8PD/QkFE/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/01MT//4+Pj/////////////////////////////////q6us/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//Dw8T////////////////////////////////////////////////////////////CwsP/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9hYWP//Pz8////////////////////////////9fX1/+Li4v///////////////////////////////////////////////////////////6Gho/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/7m5uv/////////////////////////////////09PX/R0ZJ/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/U1JU//v7/P///////////////////////////////////////////////////////////29ucP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+9vb3////////////////////////////////////////////////////////////////////////////////////////////6+vr/UFBS/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Y2Nl//7+/v////////////////////////////////+TkpT/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+ioaP////////////////////////////////////////////////////////////e3d7/Ozo9/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/1dWWP/6+vr//////////////////////////////////////////////////////////////////////////////////////7u7vP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/0tLT/////////////////////////////////+Xk5f88Oz7/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Pz5B/+zs7P///////////////////////////////////////////////////////////4uKjP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/6+usP/////////////////////////////////////////////////////////////////////////////////9/f3/ZWRm/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/99fH7//////////////////////////////////////3l5e/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9/f4H////////////////////////////////////////////////////////////y8vL/Q0JF/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/TU1P//X19f///////////////////////////////////////////////////////////////////////////9TU1P85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/z49P//n5+f/////////////////////////////////zs3O/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/9LS0v///////////////////////////////////////////////////////////6emqP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/oaCi////////////////////////////////////////////////////////////////////////////fHx9/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/5eWmP/////////////////////////////////+/v7/YF9h/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9fXmD//f39///////////////////////////////////////////////////////7+/v/VlVX/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9FREf/8PDw/////////////////////////////////////////////////////////////////+jo6P89PT//OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/SUhL//f39/////////////////////////////////+2tbb/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/7Gxsv///////////////////////////////////////////////////////////8XFxv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+bmpz/////////////////////////////////////////////////////////////////mpmb/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/sLCx//////////////////////////////////j3+P9LSk3/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9HR0n/9fX1////////////////////////////////////////////////////////////b25x/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/8bGx/////////////////////////////////////////////////////////////j4+P9LSkz/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9eXV///f39/////////////////////////////////5uanP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/5OSlP///////////////////////////////////////////////////////////9/f3/86OTz/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9hYGL//f39////////////////////////////////////////////////////////////tbW2/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//My8z/////////////////////////////////6+vr/z8+Qf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/88Oz7/5OTk////////////////////////////////////////////////////////////jIyN/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/7y8vf////////////////////////////////////////////////////////////39/f9iYmT/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/3V1d///////////////////////////////////////gYCC/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/3Z1d/////////////////////////////////////////////////////////////Hx8f9DQkX/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9WVVj/+/v7////////////////////////////////////////////////////////////0dHS/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/PDs+/+Pj5P/////////////////////////////////X19f/Ojk8/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/y8rL////////////////////////////////////////////////////////////qKep/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/6ysrf////////////////////////////////////////////////////////////////+vrq//OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/j4+Q//////////////////////////////////7+/v9oZ2n/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/11cX//9/f3///////////////////////////////////////////////////////z8/P9VVVf/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9IR0n/9fX1//////////////////////////////////////////////////////////////////X19f9JSUv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9FREf/8/Pz/////////////////////////////////728vf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/srGy////////////////////////////////////////////////////////////w8LD/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/5iXmf///////////////////////////////////////////////////////////////////////////5qam/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+rq6z/////////////////////////////////+/v7/1JRU/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0tKTf/39/f///////////////////////////////////////////////////////7+/v9wb3H/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/8+PUD/6enp////////////////////////////////////////////////////////////////////////////7e3t/0FAQ/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/1dWWP/8/Pz/////////////////////////////////o6Kk/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/nZyd////////////////////////////////////////////////////////////3t7e/zo5PP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/359f///////////////////////////////////////////////////////////////////////////////////////i4qM/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/8XExf/////////////////////////////////v7/D/QkFE/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0A/Qv/s7O3///////////////////////////////////////////////////////////+Kiov/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/1NTV///////////////////////////////////////////////////////////////////////////////////////h4OH/PDs+/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/cG9x//7+/v////////////////////////////////+Kiov/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/iYiK////////////////////////////////////////////////////////////8fHx/0NCRf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/2VkZ//+/v7///////////////////////////////////////////////////////j4+P////////////////////////////////95eXv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/86OTz/3d3d/////////////////////////////////93d3v86OTz/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zw7Pv/g4OD///////////////////////////////////////////////////////////+mpqf/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/ubm5////////////////////////////////////////////////////////////f3+A//X19f///////////////////////////9XU1f85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+KiYv//////////////////////////////////v7+/3Bvcf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/d3Z4////////////////////////////////////////////////////////////+/v7/1RTVv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/09OUf/6+vr//////////////////////////////////////////////////////9rZ2v85ODv/p6eo/////////////////////////////v7+/2pqbP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0JBRP/w8PD/////////////////////////////////xsbH/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//U09T////////////////////////////////////////////////////////////CwsP/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/n5+g////////////////////////////////////////////////////////////g4KE/zk4O/9OTVD/+Pj4////////////////////////////x8fI/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/6Kio//////////////////////////////////8/Pz/V1dZ/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/a2ps//7+/v///////////////////////////////////////////////////////v7+/2ppa/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0BAQv/t7e3//////////////////////////////////////////////////////+np6f8+PUD/OTg7/zk4O/+vr7D////////////////////////////9/f3/YF9i/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/UlFU//v7+/////////////////////////////////+srK3/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//Jycn////////////////////////////////////////////////////////////Z2Nn/Ojk8/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/h4aI////////////////////////////////////////////////////////////lZSW/zk4O/85ODv/OTg7/1NSVf/5+fn///////////////////////////++vb//OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/vb2+//////////////////////////////////T09P9GRkj/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Y2Jl//39/f///////////////////////////////////////////////////////////4SEhf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zo5PP/a2tv///////////////////////////////////////////////////////T09P9HRkn/OTg7/zk4O/85ODv/OTg7/7W0tv////////////////////////////z8/P9aWVz/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9oZ2n//v7+/////////////////////////////////5GRkv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//BwcL////////////////////////////////////////////////////////////s7Oz/Pz5B/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/bm1v////////////////////////////////////////////////////////////qKep/zk4O/85ODv/OTg7/zk4O/85ODv/V1ZZ//v7+////////////////////////////7i3uP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zo5PP/X19j/////////////////////////////////5eXl/zw7Pv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/YF9i//39/f///////////////////////////////////////////////////////////52cnv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//Hx8f///////////////////////////////////////////////////////r6+v9SUlT/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/ubm6/////////////////////////////Pz8/1hYWv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/4KCg///////////////////////////////////////d3d5/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//AwMH////////////////////////////////////////////////////////////39/f/TEtN/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/XFte//z8/P//////////////////////////////////////////////////////vLu8/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9dXF7//Pz8////////////////////////////ubm6/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Pz5B/+zs7P/////////////////////////////////Ozs7/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/YF9h//z8/P///////////////////////////////////////////////////////////7Gxsv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+1tbb///////////////////////////////////////////////////////39/f9iYWT/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//BwcL////////////////////////////8/Pz/Xl1f/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/nZye//////////////////////////////////39/f9gYGL/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//Fxcb////////////////////////////////////////////////////////////9/f3/XFtd/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/T05R//n5+f//////////////////////////////////////////////////////zs7P/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/2ZlZ//+/v7////////////////////////////Dw8T/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9NTE//+Pj4/////////////////////////////////7SztP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/fn1///7+/v///////////////////////////////////////////////////////////8bGx/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+np6j///////////////////////////////////////////////////////7+/v91dHb/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/87Oz/////////////////////////////7+/v9paGv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+3t7j/////////////////////////////////+Pj4/0tKTf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/1BQUv/w8PD////////////////////////////////////////////////////////////+/v7/b25w/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/SklM//X19f//////////////////////////////////////////////////////39/f/zo5PP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/dXV3/////////////////////////////////9XU1f87Oj3/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/2JhY//+/v7/////////////////////////////////m5qc/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/8/PkH/1dXV/////////////////////////////////////////////////////////////////9vb3P86OTz/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+hoaL///////////////////////////////////////////////////////////+Ih4n/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/88Oz7/4uLi/////////////////////////////////4GBg/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/9DQ0P/////////////////////////////////q6ur/Pz5B/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Ozo9/7q6u///////////////////////////////////////////////////////////////////////np2f/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/SUhL//T09P//////////////////////////////////////////////////////6+vs/0A/Qv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+Qj5H/////////////////////////////////6+vs/0VER/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/fHt9//////////////////////////////////////+BgIL/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zo5PP+rq6z///////////////////////////////////////////////////////////////////////////+RkZL/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+ko6X///////////////////////////////////////////////////////////+bmpz/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0ZFSP/19fX/////////////////////////////////qqqr/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9BQEP/9vb2/////////////////////////////////+Dg4f8/PkH/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/87Oj3/rKyt/////////////////////////////////////////////////////////////////////////////////7u7vP85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/Tk5Q//b29v//////////////////////////////////////////////////////+fn5/0lIS/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/9HR0v/////////////////////////////////8/Pz/ZWRm/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/4yMjf///////////////////////////////////////////6qqq/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/QkFD/769vv//////////////////////////////////////////////////////////////////////////////////////+/v7/2VkZ/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/+ysrP////////////////////////////////////////////////////////////29fb/Ozo9/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/1NTU///////////////////////////////////////o6Oj/VFNW/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9qamz/9/f3/////////////////////////////////////////////v7+/5GQkv85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/11cXv/d3d3/////////////////////////////////////////////////////////////////////////////////////////////////8PDw/3Rzdf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/86OTz/kpGT//39/f////////////////////////////////////////////////////////////7+/v90dHb/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/1pZXP/6+vr////////////////////////////////////////////t7e3/dXR2/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/88Oz7/j46Q//j4+P///////////////////////////////////////////////////////v7+/6Sjpf8+PUD/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/0xLTf+mpqf/+fn5/////////////////////////////////////////////////////////////////////////////////////////////////////////////v7+/8nIyf91dHb/QUBD/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9FREf/enl7/8/P0P////////////////////////////////////////////////////////////////////////////Ly8/+DgoT/Pz5B/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/z08P/95eHr/6urq///////////////////////////////////////////////////////+/v7/zMvM/3h3ef9CQUP/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9KSUz/jIuN/9/f4P///////////////////////////////////////////////////////////////////////////97d3v9/foD/QUBD/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/zMvM///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////19fX/0dDR/4+PkP85ODv/OTg7/0RDRv+goKH/qKip/7Oys//Gxsf/39/f//n5+f/////////////////////////////////////////////////////////////////////////////////////////////////x8fH/xMTE/5qam/86OTz/OTg7/zk4O/+CgoT/mJeZ/6qpq//Fxcb/7u7u//////////////////////////////////////////////////////////////////////////////////b29v/Q0NH/ra2u/5SUlf9DQkX/OTg7/zk4O/9zcnT/0tLT//r6+v/////////////////////////////////////////////////////////////////////////////////////////////////09PT/hoWH/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O//MzM3/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////xMTF/zk4O/85ODv/Tk1Q//39/f//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////6urr/zo5PP85ODv/OTg7/+jo6P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////1JRU/85ODv/OTg7/6OipP////////////////////////////////////////////////////////////////////////////////////////////////////////////////+cm53/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/8zMzf/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////ExMX/OTg7/zk4O/9OTVD//f39///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////n5uf/OTg7/zk4O/86OTz/6urq////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////UlFT/zk4O/85ODv/qamq/////////////////////////////////////////////////////////////////////////////////////////////////////////////////5ybnf85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/zMzN/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8PDxP85ODv/OTg7/05NUP/9/f3//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+Pj5P85ODv/OTg7/zs6Pf/t7e3///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////9SUVP/OTg7/zk4O/+xsbL/////////////////////////////////////////////////////////////////////////////////////////////////////////////////nJud/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/9cW13/Z2Zo/2dmaP9nZ2n/aGdq/2hnav9oZ2r/aGdq/2hnav9oZ2r/aGdq/2loav9paWv/aWlr/2lpa/9paWv/aWlr/2lpa/9paWv/aWlr/2lpa/9paWv/aWlr/2lpa/9paWv/aWlr/2lpa/9paWv/W1pd/zk4O/85ODv/PTw//2RkZv9kZGb/Y2Jl/2NiZf9jYmX/YmJk/2JhY/9iYWP/YmFj/2BgYv9gYGL/YGBi/2BfYv9fXmH/X15h/19eYf9eXmD/Xl1g/15dYP9eXV//XVxe/11cXv9dXF7/XFtd/1taXf9bWl3/VlVY/zk4O/85ODv/OTg7/1hYWv9bWl3/W1pd/11cXv9dXF7/XVxe/11dX/9eXWD/Xl1g/19eYP9fXmH/X15h/2BfYf9gYGL/YGBi/2BgYv9iYWP/YmFj/2JhY/9jYmX/Y2Jl/2NiZf9kY2X/ZWRm/z49QP85ODv/OTg7/1ZVWP9mZWf/ZWRm/2RkZv9jYmX/YmFk/2JhY/9gYGL/YF9h/19eYf9eXWD/XV1f/11cXv9bWl3/W1pc/1pZXP9ZWFv/WFda/1ZWWP9VVFb/VFNW/1JRVP9FREf/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/OTg7/zk4O/85ODv/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            icon_bytes = base64.b64decode(icon_data)
            with tempfile.NamedTemporaryFile(suffix='.ico', delete=False) as temp_icon:
                temp_icon.write(icon_bytes)
                temp_icon_path = temp_icon.name
            self.root.iconbitmap(temp_icon_path)
            os.unlink(temp_icon_path)
        except Exception as e:
            print(f"خطا در تنظیم آیکون: {e}")
        self.center_window(self.root, 700, 650)
        self.rules_file = ensure_file_path("rls.json", "قواعد", self.root)
        if self.rules_file == "CANCEL":
            messagebox.showinfo("خروج", "برنامه به درخواست کاربر متوقف شد.")
            self.root.destroy()
            return
        self.categories_file = ensure_file_path("cat.txt", "فهرست رده‌ها", self.root)
        if self.categories_file == "CANCEL":
            messagebox.showinfo("خروج", "برنامه به درخواست کاربر متوقف شد.")
            self.root.destroy()
            return
        if not self.rules_file or not self.categories_file:
            messagebox.showerror("خطا", "فایل‌های ضروری یافت نشدند. برنامه متوقف شد.")
            self.root.destroy()
            return
        title_frame = ttk.Frame(root)
        title_frame.pack(pady=10)
        ttk.Label(title_frame, text="P W E", font=("28 Days Later", 41), anchor="e").pack()
        ttk.Label(title_frame, text="Persian Wikipedia Editor", font=FONT_REGULAR, anchor="e").pack()
        self.stop_flag = False
        self.mode_var = tk.StringVar(value="single")
        mode_frame = ttk.LabelFrame(root, text="انتخاب حالت")
        mode_frame.pack(fill="x", padx=5, pady=5)
        ttk.Radiobutton(mode_frame, text="یک صفحه", variable=self.mode_var, value="single", command=self.toggle_mode).pack(side="right")
        ttk.Radiobutton(mode_frame, text="چند صفحه", variable=self.mode_var, value="multi", command=self.toggle_mode).pack(side="right")
        ttk.Radiobutton(mode_frame, text="رده", variable=self.mode_var, value="category", command=self.toggle_mode).pack(side="right")
        entry_frame = ttk.Frame(root)
        entry_frame.pack(fill="x", padx=5, pady=5)
        self.label_entry = ttk.Label(entry_frame, text=":نام صفحه", font=FONT_REGULAR, anchor="e")
        self.label_entry.pack(side="right")
        vcmd = (root.register(self.validate_category_number), '%P')
        self.entry = tk.Entry(entry_frame, width=50, validate="key", validatecommand=vcmd, font=FONT_REGULAR, justify="right")
        self.entry.pack(side="right", fill="x", expand=True)
        self.entry.bind("<KeyRelease>", lambda e: correct_persian_y(self.entry))
        self.entry.bind("<KeyPress>", self.prevent_special_chars_single)
        self.create_context_menu(self.entry)
        self.clear_button = ttk.Button(entry_frame, text="پاکسازی", command=self.clear_entry)
        self.clear_button.pack(side="right", padx=5)
        summary_frame = ttk.Frame(root)
        summary_frame.pack(fill="x", padx=5, pady=5)
        ttk.Label(summary_frame, text=":خلاصه ویرایش", font=FONT_REGULAR, anchor="e").pack(side="right")
        self.summary_entry = tk.Entry(summary_frame, width=40, font=FONT_REGULAR, justify="right")
        self.summary_entry.pack(side="right", padx=5)
        self.summary_entry.insert(0, "ابرابزار")
        self.summary_entry.bind("<KeyRelease>", lambda e: correct_persian_y(self.summary_entry))
        self.create_context_menu(self.summary_entry)
        self.cat_frame = ttk.LabelFrame(root, text="مدیریت رده‌ها")
        self.cat_frame.pack(fill="both", expand=True, padx=5, pady=5)
        self.cat_frame.pack_forget()
        search_cat_frame = ttk.Frame(self.cat_frame)
        search_cat_frame.pack(fill="x", padx=5, pady=5)
        ttk.Label(search_cat_frame, text="جستجو:", font=FONT_REGULAR, anchor="e").pack(side="right")
        self.cat_search_var = tk.StringVar()
        self.cat_search_var.trace_add("write", self.filter_categories)
        self.cat_search_entry = tk.Entry(search_cat_frame, textvariable=self.cat_search_var, font=FONT_REGULAR, justify="right")
        self.cat_search_entry.pack(side="right", fill="x", expand=True, padx=5)
        self.cat_search_entry.bind("<KeyRelease>", lambda e: correct_persian_y(self.cat_search_entry))
        self.create_context_menu(self.cat_search_entry)
        ttk.Button(search_cat_frame, text="پاک کردن", command=lambda: self.cat_search_var.set("")).pack(side="right", padx=5)
        self.cat_listbox = tk.Listbox(self.cat_frame, font=FONT_REGULAR)
        self.cat_listbox.pack(side="right", fill="both", expand=True)
        self.cat_listbox.bind("<Double-1>", self.insert_category_to_entry)
        cat_btn_frame = ttk.Frame(self.cat_frame)
        cat_btn_frame.pack(side="left", fill="y", padx=5)
        self.add_cat_button = ttk.Button(cat_btn_frame, text="افزودن", command=self.add_category)
        self.add_cat_button.pack(fill="x", pady=2)
        self.edit_cat_button = ttk.Button(cat_btn_frame, text="ویرایش", command=self.edit_category)
        self.edit_cat_button.pack(fill="x", pady=2)
        self.delete_cat_button = ttk.Button(cat_btn_frame, text="حذف", command=self.delete_category)
        self.delete_cat_button.pack(fill="x", pady=2)
        self.load_categories()
        done_frame = ttk.LabelFrame(root, text="صفحات ویرایش شده")
        done_frame.pack(fill="both", expand=True, padx=5, pady=5)
        self.done_list = tk.Listbox(done_frame, height=10, font=FONT_REGULAR)
        self.done_list.pack(side="right", fill="both", expand=True)
        done_scroll = ttk.Scrollbar(done_frame, orient="vertical", command=self.done_list.yview)
        done_scroll.pack(side="left", fill="y")
        self.done_list.config(yscrollcommand=done_scroll.set)
        
        self.done_list.bind("<Double-1>", self.open_page_in_browser)
        
        self.progress_var = tk.StringVar()
        self.progress_label = ttk.Label(root, textvariable=self.progress_var, font=FONT_REGULAR, anchor="e")
        self.progress_bar = ttk.Progressbar(root, orient="horizontal", mode="determinate", length=400)
        btn_frame = ttk.Frame(root)
        btn_frame.pack(pady=5)
        self.start_edit_button = ttk.Button(btn_frame, text="شروع ویرایش", width=25, command=self.start_edit)
        self.start_edit_button.pack(side="right", padx=5)
        self.stop_edit_button = ttk.Button(btn_frame, text="توقف", width=15, command=self.stop_edit, state="disabled")
        self.stop_edit_button.pack(side="right", padx=5)
        self.rule_manager_button = ttk.Button(btn_frame, text="مدیریت قواعد", command=self.open_rule_manager)
        self.rule_manager_button.pack(side="right", padx=5)
        self.cat_manager_button = ttk.Button(btn_frame, text="مدیریت رده‌ها", command=self.toggle_category_manager)
        self.cat_manager_button.pack(side="right", padx=5)
        self.about_button = ttk.Button(btn_frame, text="درباره", command=self.show_about)
        self.about_button.pack(side="right", padx=5)
        self.exit_button = ttk.Button(btn_frame, text="خروج", width=25, command=root.destroy)
        self.exit_button.pack(side="right", padx=5)
        ttk.Label(root, text="© October 2025 by Avarwand", font=FONT_REGULAR, foreground="#757575", anchor="e").pack(side="bottom", anchor="sw", padx=5, pady=7)
        self.toggle_mode()

    def center_window(self, win, width, height):
        screen_width = win.winfo_screenwidth()
        screen_height = win.winfo_screenheight()
        x = int((screen_width - width) / 2)
        y = int((screen_height - height) / 2)
        win.geometry(f"{width}x{height}+{x}+{y}")

    def toggle_mode(self):
        mode = self.mode_var.get()
        if mode == "category":
            self.label_entry.config(text=":شماره رده (عدد صحیح)")
            self.entry.configure(validate="key")
        elif mode == "multi":
            self.label_entry.config(text=":نام صفحه‌ها (با کاما جدا کنید)")
            self.entry.configure(validate="none")
        else:
            self.label_entry.config(text=":نام صفحه")
            self.entry.configure(validate="none")

    def validate_category_number(self, P):
        if self.mode_var.get() != "category":
            return True
        if P == "":
            return True
        if P.isdigit():
            num = int(P)
            return 1 <= num <= len(CATEGORY_LIST)
        return False

    def prevent_special_chars_single(self, event):
        if self.mode_var.get() == "single":
            forbidden = {",", "،", ";", "؛", "]", "[", "\\", "@", "#", "*", "&"}
            if event.char in forbidden:
                return "break"

    def create_context_menu(self, widget):
        menu = tk.Menu(widget, tearoff=0)
        menu.add_command(label="کپی", command=lambda: widget.event_generate("<<Copy>>"))
        menu.add_command(label="برش", command=lambda: widget.event_generate("<<Cut>>"))
        menu.add_command(label="چسباندن", command=lambda: widget.event_generate("<<Paste>>"))
        menu.add_command(label="انتخاب همه", command=lambda: widget.event_generate("<<SelectAll>>"))
        widget.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))

    def clear_entry(self):
        self.entry.delete(0, "end")

    def load_categories(self):
        global CATEGORY_LIST
        file_path = self.categories_file
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                CATEGORY_LIST = [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            self.save_categories()
        except PermissionError as e:
            messagebox.showerror("خطا", f"عدم دسترسی به فایل رده‌ها:\n{e}")
            return
        self.filter_categories()

    def save_categories(self):
        file_path = self.categories_file
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                for cat in CATEGORY_LIST:
                    f.write(f"{cat}\n")
        except PermissionError as e:
            messagebox.showerror("خطا", f"عدم دسترسی برای ذخیره فایل رده‌ها:\n{e}")

    def filter_categories(self, *args):
        search_term = self.cat_search_var.get().strip().lower()
        self.cat_listbox.delete(0, "end")
        for idx, cat in enumerate(CATEGORY_LIST, 1):
            if not search_term or search_term in cat.lower():
                self.cat_listbox.insert("end", f"{idx}: {cat}")

    def add_category(self):
        def save_new_cat():
            new_cat = cat_entry.get().strip()
            if not new_cat:
                messagebox.showerror("خطا", "نام رده نمی‌تواند خالی باشد.")
                return
            CATEGORY_LIST.append(new_cat)
            self.save_categories()
            self.filter_categories()
            add_win.destroy()

        add_win = tk.Toplevel(self.root)
        add_win.title("افزودن رده جدید")
        add_win.transient(self.root)
        add_win.grab_set()
        add_win.focus_force()
        self.center_window(add_win, 380, 140)
        ttk.Label(add_win, text="نام رده جدید:", font=FONT_REGULAR, anchor="e").pack(padx=10, pady=5)
        cat_entry = tk.Entry(add_win, width=45, font=FONT_REGULAR, justify="right")
        cat_entry.pack(padx=10, pady=5)
        cat_entry.bind("<KeyRelease>", lambda e: correct_persian_y(cat_entry))
        self.create_context_menu(cat_entry)
        btn_frame = ttk.Frame(add_win)
        btn_frame.pack(pady=8)
        ttk.Button(btn_frame, text="ذخیره", command=save_new_cat).pack(side="right", padx=5)
        ttk.Button(btn_frame, text="خروج", command=add_win.destroy).pack(side="right", padx=5)

    def edit_category(self):
        sel = self.cat_listbox.curselection()
        if not sel:
            messagebox.showwarning("هشدار", "یک رده انتخاب کنید.")
            return
        idx = sel[0]
        displayed_cat = self.cat_listbox.get(idx)
        cat_idx = int(displayed_cat.split(":")[0]) - 1
        old_cat = CATEGORY_LIST[cat_idx]

        def save_edit_cat():
            new_cat = cat_entry.get().strip()
            if not new_cat:
                messagebox.showerror("خطا", "نام رده نمی‌تواند خالی باشد.")
                return
            CATEGORY_LIST[cat_idx] = new_cat
            self.save_categories()
            self.filter_categories()
            edit_win.destroy()

        edit_win = tk.Toplevel(self.root)
        edit_win.title("ویرایش رده")
        edit_win.transient(self.root)
        edit_win.grab_set()
        edit_win.focus_force()
        self.center_window(edit_win, 380, 140)
        ttk.Label(edit_win, text="نام رده:", font=FONT_REGULAR, anchor="e").pack(padx=10, pady=5)
        cat_entry = tk.Entry(edit_win, width=45, font=FONT_REGULAR, justify="right")
        cat_entry.insert(0, old_cat)
        cat_entry.pack(padx=10, pady=5)
        cat_entry.bind("<KeyRelease>", lambda e: correct_persian_y(cat_entry))
        self.create_context_menu(cat_entry)
        btn_frame = ttk.Frame(edit_win)
        btn_frame.pack(pady=8)
        ttk.Button(btn_frame, text="ذخیره", command=save_edit_cat).pack(side="right", padx=5)
        ttk.Button(btn_frame, text="خروج", command=edit_win.destroy).pack(side="right", padx=5)

    def delete_category(self):
        sel = self.cat_listbox.curselection()
        if not sel:
            messagebox.showwarning("هشدار", "یک رده انتخاب کنید.")
            return
        idx = sel[0]
        displayed_cat = self.cat_listbox.get(idx)
        cat_idx = int(displayed_cat.split(":")[0]) - 1
        if messagebox.askyesno("تأیید حذف", f"آیا مطمئن هستید که '{CATEGORY_LIST[cat_idx]}' حذف شود؟"):
            del CATEGORY_LIST[cat_idx]
            self.save_categories()
            self.filter_categories()

    def insert_category_to_entry(self, event):
        if self.mode_var.get() != "category":
            return
        sel = self.cat_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        displayed_cat = self.cat_listbox.get(idx)
        cat_idx = int(displayed_cat.split(":")[0]) - 1
        self.entry.delete(0, "end")
        self.entry.insert(0, str(cat_idx + 1))

    def toggle_category_manager(self):
        if self.cat_frame.winfo_ismapped():
            self.cat_frame.pack_forget()
        else:
            self.cat_frame.pack(fill="both", expand=True, padx=5, pady=5)
            self.cat_search_var.set("")

    def open_rule_manager(self):
        rule_win = tk.Toplevel(self.root)
        rule_win.title("مدیریت قواعد")
        rule_win.transient(self.root)
        rule_win.grab_set()
        rule_win.focus_force()
        self.center_window(rule_win, 700, 500)
        RuleManagerApp(rule_win, self)

    def show_about(self):
        about_win = tk.Toplevel(self.root)
        about_win.title("PWE درباره")
        about_win.transient(self.root)
        about_win.grab_set()
        about_win.focus_force()
        self.center_window(about_win, 400, 250)
        ttk.Label(about_win, text="PWE: Persian Wikipedia Editor", font=FONT_BOLD, anchor="e").pack(pady=10)
        ttk.Label(about_win, text="ابزاری قدرتمند برای ویرایش خودکار صفحه‌های ویکی‌پدیای پارسی", font=FONT_REGULAR, justify="center", anchor="e").pack(pady=5)
        ttk.Label(about_win, text="Avarwand :سازنده", font=FONT_REGULAR, justify="center", anchor="e").pack(pady=5)
        ttk.Label(about_win, text="۲۵۸۴ مهر", font=FONT_REGULAR, justify="center", anchor="e").pack(pady=5)
        ttk.Label(about_win, text="payam_avar@yahoo.com", font=FONT_REGULAR, justify="center", anchor="e").pack(pady=5)
        ttk.Button(about_win, text="بستن", command=about_win.destroy).pack(pady=10)

    def start_edit(self):
        if self.stop_flag:
            self.stop_flag = False
        mode = self.mode_var.get()
        pages = []
        if mode == "single":
            page = self.entry.get().strip()
            if not page:
                messagebox.showerror("خطا", "نام صفحه را وارد کنید.")
                return
            forbidden_chars = {",", "،", ";", "؛", "@", "#", "*", "}", "{", "\\", "[", "]"}
            if any(ch in page for ch in forbidden_chars):
                messagebox.showerror("خطا", f"نام صفحه نمی‌تواند شامل این کاراکترها باشد: {forbidden_chars}")
                return
            pages = [page]
        elif mode == "multi":
            text = self.entry.get().strip()
            if not text:
                messagebox.showerror("خطا", "نام صفحه‌ها را وارد کنید.")
                return
            pages = [p.strip() for p in re.split(r'[،,]', text) if p.strip()]
            if not pages:
                messagebox.showerror("خطا", "حداقل یک نام صفحه معتبر وارد کنید.")
                return
        elif mode == "category":
            cat_num = self.entry.get().strip()
            if not cat_num.isdigit():
                messagebox.showerror("خطا", "شماره رده معتبر نیست.")
                return
            idx = int(cat_num) - 1
            if not (0 <= idx < len(CATEGORY_LIST)):
                messagebox.showerror("خطا", "شماره رده در لیست موجود نیست.")
                return
            cat_name = CATEGORY_LIST[idx]
            try:
                cat = pywikibot.Category(site, cat_name)
                pages = [str(page.title()) for page in cat.articles()]
            except Exception as e:
                messagebox.showerror("خطا", f"دریافت صفحات رده ناموفق بود:\n{e}")
                return
            if not pages:
                messagebox.showinfo("اطلاع", "این رده صفحه‌ای ندارد.")
                return
        self.done_list.delete(0, "end")
        self.progress_var.set("در حال شروع ویرایش ...")
        self.progress_label.pack()
        self.progress_bar.pack()
        # غیرفعال کردن دکمه‌ها و فیلدهای ورودی هنگام شروع ویرایش
        self.rule_manager_button.config(state="disabled")
        self.cat_manager_button.config(state="disabled")
        self.exit_button.config(state="disabled")
        self.clear_button.config(state="disabled")
        self.entry.config(state="disabled")
        self.summary_entry.config(state="disabled")
        self.start_edit_button.config(state="disabled")
        self.stop_edit_button.config(state="normal")
        self.about_button.config(state="disabled")
        self.add_cat_button.config(state="disabled")
        self.edit_cat_button.config(state="disabled")
        self.delete_cat_button.config(state="disabled")
        threading.Thread(target=self.edit_pages, args=(pages,), daemon=True).start()

    def stop_edit(self):
        self.stop_flag = True
        self.progress_var.set("در حال توقف ویرایش...")
        # فقط دکمه توقف را غیرفعال می‌کنیم تا از کلیک‌های مکرر جلوگیری شود
        self.stop_edit_button.config(state="disabled")
        # پیام‌باکس را اینجا نمایش ندهید - در تابع edit_pages نمایش داده خواهد شد

    def edit_pages(self, pages):
        total = len(pages)
        self.progress_bar["maximum"] = total
        self.progress_bar["value"] = 0
        edit_summary = self.summary_entry.get().strip() or "ابرابزار"
        
        for i, page_name in enumerate(pages, 1):
            if self.stop_flag:
                self.root.after(0, self.progress_var.set, "ویرایش متوقف شد.")
                break
                
            self.progress_var.set(f"ویرایش صفحه {i} از {total}: {page_name}")
            self.progress_bar["value"] = i
            self.root.update_idletasks()
            
            try:
                # بررسی stop_flag قبل از شروع ویرایش صفحه
                if self.stop_flag:
                    break
                    
                page = pywikibot.Page(site, page_name)
                
                # بررسی stop_flag بعد از بارگذاری صفحه
                if self.stop_flag:
                    break
                    
                old_text = page.text
                
                # بررسی stop_flag قبل از اعمال تغییرات
                if self.stop_flag:
                    break
                    
                new_text = self.apply_multiple_fixes(old_text)
                
                # بررسی stop_flag بعد از اعمال تغییرات
                if self.stop_flag:
                    break
                    
                if new_text != old_text:
                    page.text = new_text
                    
                    # بررسی stop_flag قبل از ذخیره صفحه
                    if self.stop_flag:
                        break
                        
                    page.save(summary=edit_summary)
                    self.root.after(0, self.done_list.insert, "end", f"✔ ویرایش شد: {page_name}")
                else:
                    self.root.after(0, self.done_list.insert, "end", f"بدون تغییر: {page_name}")
                    
                # بررسی stop_flag قبل از تاخیر
                if self.stop_flag:
                    break
                    
                time.sleep(1)
                
            except Exception as e:
                self.root.after(0, self.done_list.insert, "end", f"❗ خطا در ویرایش {page_name}: {e}")
                
                # بررسی stop_flag بعد از خطا
                if self.stop_flag:
                    break
        
        # پایان ویرایش - بازنشانی وضعیت
        if self.stop_flag:
            self.root.after(0, lambda: self.progress_var.set("ویرایش متوقف شد."))
            self.root.after(0, lambda: messagebox.showinfo("اطلاع", "فرآیند ویرایش متوقف شد."))
        else:
            self.root.after(0, lambda: self.progress_var.set("فرآیند ویرایش به پایان رسید."))
            self.root.after(0, lambda: messagebox.showinfo("اطلاع", "ویرایش تمام صفحات به پایان رسید."))
        
        self.root.after(0, self.progress_label.pack_forget)
        self.root.after(0, self.progress_bar.pack_forget)
        
        # فعال کردن دوباره دکمه‌ها و فیلدهای ورودی
        self.root.after(0, self.enable_ui_after_edit)

    def enable_ui_after_edit(self):
        """دوباره فعال کردن رابط کاربری پس از پایان ویرایش"""
        self.stop_flag = False
        self.rule_manager_button.config(state="normal")
        self.cat_manager_button.config(state="normal")
        self.exit_button.config(state="normal")
        self.clear_button.config(state="normal")
        self.entry.config(state="normal")
        self.summary_entry.config(state="normal")
        self.start_edit_button.config(state="normal")
        self.stop_edit_button.config(state="disabled")
        self.about_button.config(state="normal")
        self.add_cat_button.config(state="normal")
        self.edit_cat_button.config(state="normal")
        self.delete_cat_button.config(state="normal")


    def apply_multiple_fixes(self, text):
        rule_manager = RuleManagerApp(self.root, self, initialize=False)
        
        # استفاده از نسخه پیشرفته محافظت
        processed_text = apply_rules_protected(
            text, 
            rule_manager.rules,
            protect_links_and_templates=rule_manager.protect_links_var.get(),
            remove_extra_spaces=rule_manager.remove_extra_spaces_var.get()
        )
        
        return processed_text

    def open_page_in_browser(self, event):
        sel = self.done_list.curselection()
        if not sel:
            return
        text = self.done_list.get(sel[0])
        if text.startswith("✔ ویرایش شد:"):
            page_name = text.split(":", 1)[1].strip()  # استخراج نام صفحه
            encoded_page_name = quote(page_name)  # encode برای URL معتبر
            url = f"https://fa.wikipedia.org/wiki/{encoded_page_name}"
            webbrowser.open(url)

###################################################- R U N

if __name__ == "__main__":
    root = tk.Tk()
    app = WikiEditorApp(root)
    root.mainloop()